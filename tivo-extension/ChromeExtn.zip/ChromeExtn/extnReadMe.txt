/*chrome Extension  */

chromeExtn/
		chromeExtnResources/
			contentScript.js			--> responsible for loading the chrome extension in an iframe.
			UiHandler.js				--> responsible for all the actions and communicating between extension and application.
					
		common/							--> future implementation.
		
		core/							--> Messenger and application JSON skeleton.
		
		resources/						--> extension related custom css,images,js.
		
		vendors/						--> External libraries.
		
		views/							--> Html for crawler form and iframe.