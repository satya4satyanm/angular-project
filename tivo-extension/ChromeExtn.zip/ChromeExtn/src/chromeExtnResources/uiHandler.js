var mode = "dev";
if (mode == "prod") {
    $("#devMode").hide();
}
var domainUrl = "http://172.26.119.81:8000";
var assetTypeObject = [];
var pageObj = {};
var subsessionObj = {};
var linkObj = {};
var fieldObj = {};
var editClicked = false;
var stateManager = {};
var roviCurrentQ;
var definitionType;


var actionObject = {
    "action": "",
    "type": "css selector",
    "value": ""
}

var signinObject = {
    "preActions": [],
    "loginUrl": "",
    "password": {
        "content": "",
        "value": "",
        "type": "css selector"
    },
    "userName": {
        "content": "",
        "value": "",
        "type": "css selector"
    },
    "postActions": []
}

$.fn.hasAttr = function(name) {
    return this.attr(name) !== undefined;
};

function noscript(strCode) {
    var html = $(strCode.bold());
    html.find('script').remove();
    return html.html();
}

var iframe = $('#roviTiVoApp').find("iframe")[0];
if (!iframe) {
    iframe = $('#roviTiVoApp')[0];
};
/* listining messages from extension*/
var boundIframeListener = function(e) {

    if (e.data[0] == "definitionType" && e.data[1] == 'login') {
        definitionType = e.data[1];
        localStorage.setItem('definitionType', definitionType);
        roviCurrentQ = 0;
        throwMessage();
    } else if (e.data[0] == "stateManager") {

        definitionType = localStorage.getItem('definitionType');
        localStorePreActions = localStorage.getItem('localStorePreActions');
        if (definitionType == 'login') {
            checkLoginStatus(localStorePreActions);
        } else if (localStorage.getItem('localStorePreActions') != null) {
            Messenger().post("Please validate or save the definition.");
            changeTab(3);

        } else {
            roviCurrentQ = 1;
            Messenger.options = {
                extraClasses: 'messenger-fixed messenger-on-bottom messenger-on-right',
                theme: 'flat'
            }
            stateManager = e.data[1];

            pageObj = stateManager.pages;
            pageObj.push({
                "actualUrl": "",
                "mappingPaused": false,
                "assets": []
            });

            throwMessage();
        }
        localStorage.setItem('definitionType', '');
    }

    if (e.data[0] == "loginJSON") {

        result = e.data[1];
        getUserLoginDetails(result);

    }

    if (e.data[0] == "saveSuccess") {
        localStorage.clear();
        Messenger().post("Definition saved successfully..!");
    }

    if (e.data[0] == "saveError") {
        Messenger().post({
            message: 'Definition save error..!',
            type: 'error'
        });
    }


    if (e.data[0] == "goBack") {
        localStorage.clear();

        // show msngr
        var roviMsg = Messenger().post({
            message: 'Data mapped till now will be lost. Would you like to proceed?',
            type: 'info',
            hideAfter: 1200,
            actions: {
                ok: {
                    label: 'Ok',
                    action: function() {
                        iframe.contentWindow.postMessage([
                            'goBackResponse'
                        ], '*');
                    }
                },
                cancel: {
                    label: 'Cancel',
                    action: function() {
                        // do nothing, just close the roviMsg
                        return roviMsg.cancel();
                    }
                }
            }
        });
    }


    if (e.data[0] == "mouseOver") {
        $("#span" + e.data[1]).addClass("class-highlighter");
    }
    if (e.data[0] == "mouseOut") {
        $("#span" + e.data[1]).removeClass("class-highlighter");
    }


    if (e.data[0] == "start_selection") {

    }



    if (e.data[0] == "editLink") {
        $('#linksOrFieldsDropdown').val('links');
        $("#selectorVal").val(e.data[1].value)
    }
    if (e.data[0] == "editField") {
        $('#linksOrFieldsDropdown').val('fields');
        $("#assetType").val(e.data[1].assetType);
        $("#assetType").trigger("change");
        $("#assetSubType").val(e.data[1].name);
        $("#selectorVal").val(e.data[1].value)
    }


    if (e.data[0] == "createLabels") {
        createlabels(e.data[1], e.data[2]);
    }

    if (e.data[0] == "clearValidateResult") {
        $(".modal-body").empty();
        $(".modal-body").text("Waiting for validation result..!");
    }
    // validate results binding //
    if (e.data[0] == "validate") {
        $(".modal-body").empty();
        var json = e.data[1];
        validateModal.style.display = "block";

        var kk = 0;
        var array = [];
        for (var k in json) //keys.push(k);
        {
            array.push(k);
            if (json[k].links != null) {

                if (json[k].links.length > 0) {
                    $(".modal-body").append("<h5 class='validateHeader1'>" + k + "</h5>");
                }

                $(".modal-body").append("<th class='validateHeader2'>" + "Links" + "</th>");

                $(".modal-body").append('<table id="example_' + kk + '" class="display rowclass" cellspacing="0" width="100%"><thead><tr></tr></thead></table></br>');
                $('#example_' + kk)
                    .removeClass('display')
                    .addClass('table table-striped');
                var tr;
                tr = $('<tr/>');

                $('#example_' + kk).append(tr);

                $('#example_' + kk + ' tr').addClass('rowborder');
                for (i = 0; i < json[k].links.length; ++i) {
                    tr = $('<tr/>');
                    var id = $(this).attr("id");
                    tr.append('<td><span class="vlinks" style="font-size:15px">' + json[k].links[i] + '</span></td>');
                    $('#example_' + kk)
                        .removeClass('display')
                        .addClass('table table-striped');
                    $('#example_' + kk).append(tr);
                }

            }
            var splitedUrl;
            $(".vlinks").bind("mouseover", function(e) {
                var mouseoverUrl = $(e.target).text()
                var windowUrl = (window.location.href).split('?')[0]
                var mouseOverUrlSplitArray = mouseoverUrl.split('/');
                var windowUrlSplitArray = windowUrl.split('/');
                mouseOverUrlSplitArray = $(mouseOverUrlSplitArray).not(windowUrlSplitArray).get();
                splitedUrl = "/" + mouseOverUrlSplitArray.join('/');
                $("[href*='" + splitedUrl + "']").css("outline", "3px solid #cdd827");
                //console.log("window url" + windowUrl);
            });
            $(".vlinks").bind("mouseout", function(e) {
                $("[href*='" + splitedUrl + "']").css("outline", "none");
            });

            if (json[k].fields != null && json[k].fields[0] != null) {
                if (json[k].fields.length > 0) {
                    $(".modal-body").append("<h5 class='validateHeader1'>" + k + "</h5>");
                }
                $(".modal-body").append("<th class='validateHeader2'>" + "Fields" + "</th>");
                $(".modal-body").append('<table id="example1_' + kk + '" class="display rowclass" cellspacing="0" width="100%"><thead><tr></tr></thead></table></br>');
                $('#example1_' + kk)
                    .removeClass('display')
                    .addClass('table table-striped');
                var tr1;
                tr1 = $('<tr/>');
                $('#example1_' + kk).append(tr1);
                $('#example1_' + kk + ' tr').addClass('rowborder');
                for (var l in json[k].fields[0]) {

                    tr1.append("<th>" + l + "</th>");
                    $('#example1_' + kk).append(tr1);
                }
                tr1 = $('<tr/>');
                for (var l in json[k].fields[0]) {
                    tr1.append('<td><span class="vfields" style="font-size:15px">' + json[k].fields[0][l] + "</span></td>");

                    $('#example1_' + kk)
                        .removeClass('display')
                        .addClass('table table-striped');
                    $('#example1_' + kk).append(tr1);

                }

            }
            var mouseoverText;
            var fieldMouseOver = [];
            $(".vfields").bind("mouseover", function(e) {
                mouseoverText = $(e.target).text()
                $('*').each(function() {
                    if ($(this).text() == mouseoverText) {
                        fieldMouseOver.push($(this));
                    }
                });

                for (i = 0; i < a.length; i++) {
                    if (fieldMouseOver[i].parents('#userModalPopup1').length < 1) {
                        $(fieldMouseOver[i]).css("outline", "3px solid #cdd827");
                    }
                }
            }).bind("mouseout", function(e) {
                for (i = 0; i < a.length; i++) {
                    $((fieldMouseOver[i])).css("outline", "none");
                }
            });


            kk++;
        }
    }
//ends validate results binding//

}
//checking login defination  status//
function checkLoginStatus(localStorePreActions){
  if (localStorePreActions != "null" && signinObject.password.content == "" && signinObject.userName.content == "") {
      changeTab(4);
      createLoginSubSession();
  } else {
      Messenger().post("Please validate or save the definition.");
      changeTab(3);

  }
}
//checking userLogin details//
function getUserLoginDetails(result){

          if (result != null) {
              result = JSON.parse(result)[0];
              if (result != null && result.credential.userName.content != "") {
                  postActionObj = result.credential.postActions[0];
                  if (!window.location.hash) {
                      preActionObj = result.credential.preActions[0];

                      if (window.location.href != preActionObj.url + "?action=roviWebScraperActive") {
                          window.location.href = preActionObj.url + "#loaded" + "?action=roviWebScraperActive";
                      }
                  }
                  userNameValue = result.credential.userName.value.split("=").pop().slice(0, -1);
                  passwordValue = result.credential.password.value.split("=").pop().slice(0, -1);
                  clickValue = postActionObj.value.slice(1);
                  userNameValue = userNameValue.replace(/'/g, '');
                  passwordValue = passwordValue.replace(/'/g, '');
                  if (result.credential.userName.value.startsWith("[class^=")) {
                      document.getElementByClass(userNameValuee).value = result.credential.userName.content;
                  } else {
                      document.getElementById(userNameValue).value = result.credential.userName.content;
                  }
                  if (result.credential.password.value.startsWith("[class^=")) {
                      document.getElementByClass(passwordValue).value = result.credential.password.content;
                  } else {
                      document.getElementById(passwordValue).value = result.credential.password.content;
                  }
                  if (postActionObj.value.startsWith(".")) {
                      document.getElementByClass(clickValue).click();
                  } else {
                      clickValue = clickValue.split(" ")[0];
                      document.getElementById(clickValue).click();
                  }

              }
          }
}
window.addEventListener('message', boundIframeListener, true);
rightClickedElement = "";
//mouseover  and mouseout on pagelevel
function pageLevelMouseover() {
    $("*").mouseover(function(e) {
        if (($(e.target).parents('.window').length > 0) || ($(e.target).parents('#cntnr').length > 0) || ($(e.target).parents('.messenger-message').length > 0) || ($(e.target) == $('.messenger-message') > 0) || ($(e.target).parents('.label').length > 0) || ($(e.target).attr('id') == "cntnr") || ($(e.target).attr('class') == "label") || ($(e.target).attr('id') == "collapse-right") || ($(e.target).parents('#l1').length > 0) || $(e.target).parents('.messenger').length > 0 || $(e.target).attr('class') == "messenger" || ($(e.target).parents('#collapse-right').length > 0)) {} else {
            $(e.target).addClass("class-highlighter-red");
        }
    });

    $("*").mouseout(function(e) {
        $(e.target).removeClass("class-highlighter-red");
    });
}
//ends mouseover  and mouseout on pagelevel
var refreshedit = "";
var currentMatchIndexInUIHandler = null;
var fullpath;
var multipleSelector = [];
var elementTreeHasA = false;
var elementTreeHasImage = false;
var editIndex, id, assetToAdd;
//#################  sub session flow start
currentSubsession = 'listing';
roviCurrentQ = 0;
var mandatoryFieldMapingState = false;
var assetIdMappingInProgress = false;
var assetTitleMappingInProgress = false;
var paginationInActive = false;
var scrollPaginationInActive = false;

//start Mapping //
$("#start").click(function() {
    $(this).hide();
    roviCurrentQ++;
    throwMessage();
    $("#div_Scheme").show();
});

// mandatatorty subsession flow //
function createMandatoryAttributeSubSession() {
    $("#subSessionContainer").show();
    $("#subSessionControls").show();
    $("#subSessionDone").show();

    mandatoryFieldMapingState = true;

    if (roviCurrentQ == 3) {
        assetIdMappingInProgress = true;
        var select = $('#assetSubType'),
            options = select.find('option');
        var visibleItems = options.filter('[value*="' + 'asset Id' + '"]').show();
        if (visibleItems.length > 0) {
            select.val(visibleItems.eq(0).val());
        }


    } else if (roviCurrentQ == 4) {
        assetIdMappingInProgress = false;
        assetTitleMappingInProgress = true;

    }

    pageLevelMouseover();
    $(document).bind("contextmenu", rightClick);

    pageObj[0].assets[currentAssetIndex].subSessions.mandatoryAttributes = {
        "active": true,
        "noOfAttributesMapped": 1
    }

    //disableLinks();
    $("#subSessionDone").off('click').on("click", function() {
        //enableLinks();
        roviCurrentQ++;
        throwMessage();
        $("#subSessionDone").off("click");

        if (stateManager.allQs[roviCurrentQ].callback != undefined) {
            var callback = stateManager.allQs[roviCurrentQ].callback;
            window[callback]();
        }
    });


}
/*ends mandatory subsession */

/* Attribute creation  subsession*/

function createAttributeSubSession() {
    mandatoryFieldMapingState = false;
    assetTitleMappingInProgress = false;
    $("#subSessionContainer").show();
    $("#subSessionControls").show();
    $("#subSessionDone").show();

    pageObj[0].assets[currentAssetIndex].subSessions.allAttributes = {
        "active": true,
        "noOfAttributesMapped": 1
    }

    if (stateManager.allQs[roviCurrentQ].yesMessage != "") {
        throwMessage(stateManager.allQs[roviCurrentQ].yesMessage, true);
    }


    $("#subSessionDone").off('click').on("click", function() {
        roviCurrentQ++;
        throwMessage();
        $("#subSessionDone").off("click");
    });

    if (roviCurrentQ == 8) {
        $("#subSessionDone").text("Done");
    } else {
        $("#subSessionDone").text("Done");
    }

}
// ends Attribute creation //

/*detail subsesion */
function createDetailSubSession() {
    roviCurrentQ = 10;
    throwMessage();
    $("#subSessionDone").bind("click", function() {
        roviCurrentQ++;
        throwMessage();
        $("#subSessionDone").unbind("click");
    });
}
//ends detail subsesion //

/*pagination subsession*/
function createPaginationSubSession() {
    paginationInActive = true;
    $("#subSessionContainer").show();
    $("#subSessionControls").show();
    $("#subSessionDone").show();

    pageObj[0].assets[currentAssetIndex].subSessions.pagination = {
        "active": true,
        "noOfAttributesMapped": 1
    }

    $("#subSessionContainer .subSessionLabels.active").removeClass("active");

    if ($("#subsessionbtn").text().indexOf("Pagination") > -1) {} else {
        var btn = $('<button/>', {
            text: "Pagination",
            class: 'subSessionLabels active',
            click: function() {

            }
        });
        $("#subsessionbtn").append(btn);
        $("#subSessionContent").empty();
    }


    if (stateManager.allQs[roviCurrentQ].paginationType == "click") {
        //disableLinks();

        throwMessage(stateManager.allQs[roviCurrentQ].yesMessage, true);

        $("#subSessionDone").bind("click", function() {
            paginationInActive = false;
            //enableLinks();
            roviCurrentQ += 2;
            throwMessage();
            $("#subSessionDone").unbind("click");

            if (stateManager.allQs[roviCurrentQ].callback != undefined) {
                var callback = stateManager.allQs[roviCurrentQ].callback;
                window[callback]();
            }
        });
    } else if (stateManager.allQs[roviCurrentQ].paginationType == "scroll") {
        scrollPaginationInActive = true;
        $("#subSessionDone").bind("click", function() {
            scrollPaginationInActive = false;
            roviCurrentQ++;
            throwMessage();
            $("#subSessionDone").unbind("click");

            if (stateManager.allQs[roviCurrentQ].callback != undefined) {
                var callback = stateManager.allQs[roviCurrentQ].callback;
                window[callback]();
            }
        });
    }


}
//ends pagination subsession //



function next() {
    roviCurrentQ++;
    throwMessage();
    if (stateManager.allQs[roviCurrentQ].callback != undefined) {
        var callback = stateManager.allQs[roviCurrentQ].callback;
        window[callback]();
    }
}

function nextEnd() {
    Messenger().post("Please validate or save the definition.");
    changeTab(3);
}


function enableLinks() {
    $("a").each(function() {
        $(this).attr("href", $(this).attr("rel"));
        $(this).removeAttr("rel");
    });
    return true;
}



function disableLinks() {
    $("a").each(function() {
        $(this).attr("rel", $(this).attr("href"));
        $(this).attr("href", "javascript:;");
    });
    return true;
}


/* new Asset creation*/
function createNewAsset() {
    $("#div_Scheme").show();
    roviCurrentQ = 1;
    throwMessage();
}
//ends//

/* throw messages based on question type */
function throwMessage(roviMsgtxt = "", nestedroviMsg = false) {
    if (nestedroviMsg == true) {
        Messenger().post({
            message: roviMsgtxt,
            hideAfter: 15
        });
    } else if (stateManager.allQs[roviCurrentQ].type == "Informative") {
        Messenger().post({
            message: stateManager.allQs[roviCurrentQ].q,
            hideAfter: 15
        });

        if (stateManager.allQs[roviCurrentQ].callback != undefined) {
            var callback = stateManager.allQs[roviCurrentQ].callback;
            window[callback]();
        }

        //return true;
    } else if (stateManager.allQs[roviCurrentQ].type == "YesOrNo") {

        var msg = stateManager.allQs[roviCurrentQ].q;
        var ycb = stateManager.allQs[roviCurrentQ].yesCallback;
        var ncb = stateManager.allQs[roviCurrentQ].noCallback;


        var roviMsgR;
        roviMsgR = Messenger().post({
            message: msg,
            hideAfter: 1200,
            actions: {
                Yes: {
                    action: function() {
                        window[ycb]();
                        return roviMsgR.cancel();
                    }
                },
                No: {
                    action: function() {
                        window[ncb]();
                        return roviMsgR.cancel();
                    }
                }
            }
        });
    }
}
//###################  sub session flow end

iframe.contentWindow.postMessage([
    'visitUrl', window.location.href
], '*');

//#############selector path and unique paths//

$(document).mouseup(function(e) {
    var selection = window.getSelection();
    var text = selection.toString();
    var len = text.length;
    if ($('pre').find(e.target).length > 0 && len > 1) {
        getSelectionText(e);
    } else {
        $("#qs-popup").hide();
    }
});


var htmlContent = noscript($('html').html());

function getSelectionText(e) {
    var selection = window.getSelection();
    var text = selection.toString();
    var len = text.length;
    var range = selection.getRangeAt(0).cloneRange();
    var rect = range.getClientRects()[0];
    var left = rect.left;
    var top = rect.top;
    var right = rect.right;
    var mid = (left + right) / 2
    var scroll = $(".modal-body").scrollTop();

    // position the popup
    var showPopup = {
        'top': top + scroll - 80,
        'left': mid - 170
    };


    var id = 'qs-popup';
    var id1 = 'button-popup';
    if ($('#' + id).length) {} else {
        $(".modal-body").append('<div id="' + id + '"><div id="buttonRaper" style="display:inline-flex;"><input id="finalizedObjId" class="' + id1 + '"type="button" style="margin:3px;" value="Ok"/><input id="finalizedObjIdCncl" class="' + id1 + '" type="button" style="margin:3px;" value="Clear"/></div></div>');
    }
    $('#' + id).show();

    // style popup menu
    $('#' + id).css({
        'background': '#262626',
        'font-size': '24px',
        'border-radius': '4px',
        'box-sizing': 'border-box',
        'position': 'absolute',
        'top': showPopup.top,
        'left': showPopup.left
    });
    $('.' + id1).css({
        'background': '#3498db',
        '-webkit-border-radius': '8',
        '-moz-border-radius': '8',
        'border-radius': '8px',
        'border': '0',
        'font-family': 'Arial',
        'color': '#ffffff',
        'font-size': '15px',
        'padding': '5px',
        'text-decoration': 'none'
    });


    $('#finalizedObjId').bind("click", function() {
        iframe.contentWindow.postMessage([
            'source', text
        ], '*');
        $('#' + id).hide();
        $('#validateModal').modal('hide');
    });
    $('#finalizedObjIdCncl').bind("click", function() {
        $('#' + id).hide();
        selection.empty();

    });

    $(".modal-body pre").unbind('mouseup');

    return text;
}


hoverByClass = function(classname, colorover) {
    var elementSelector = classname.split("/").join(" ");
    var elms = $(elementSelector);
    for (var i = 0; i < elms.length; i++) {
        $(elms[i]).addClass("class-highlighter");
    }

}

var reachedWithFewItems = false;
/* this should return the unique ID/class/path, if user is not satisfied with the selector he will enter regexp */
getPathTo = function(element) {
    if (element.id !== '') {
        return '#' + element.id;
    } else if (element.className.split(" ")[0] !== '' && element.className.split(" ")[0] !== 'class-highlighter' && element.className.split(" ")[0] !== 'class-highlighter-red') {
        if (element.parentNode.childNodes.length > 1) {
            var nodeList = Array.prototype.slice.call(element.parentNode.childNodes);
            return '.' + element.className.split(" ")[0] + ":nth-child(" + nodeList.indexOf(element) + ")";
        } else {
            return '.' + element.className.split(" ")[0]; // use cases can be there for multiple class selector
        }
    } else {
        if (element.parentNode.childNodes.length > 1) {
            var nodeList = Array.prototype.slice.call(element.parentNode.childNodes);

            return getPathTo(element.parentNode) + ' ' + element.tagName + ":nth-child(" + nodeList.indexOf(element) + ")";
        } else {
            if (localStorage.getItem('definitionType') == "login") {
                return getPathTo(element.parentNode)
            } else {
                return getPathTo(element.parentNode) + ' ' + element.tagName;
            }
        }
    }
}
currentElement = null;
//currentEleSelector = "";
schemaName = "";
var labelIndex = 0;
finalSelector = "";
var hrefAttributes = [];

$("a").each(function() {
    if ($(this).parents('#cntnr').length < 1) {
        if ($(this).attr("href") != undefined) {
            if (!($(this).attr("href").indexOf('javascript:') > -1)) {
                $(this).attr("href", $(this).attr("href") + "?action=roviWebScraperActive");
            }
        }
    }
});
//checks if it is  href element //
function checkElementHasA(elem) {
    if ($(elem)[0].tagName == "A") {
        return true;
    } else {
        if ($(elem)[0].tagName == "BODY") {
            return false;
        } else {
            return checkElementHasA($(elem).parent());
        }
    }
}

//checks if it is  src element //
function checkElementHasImage(elem) {
    if ($(elem)[0].tagName == "IMG") {
        return true;
    } else {
        return false;
    }
}
// gets elements full path from the html body//
function getParentIdClassNameIfFoundMore(elem) {
    var selectedElementPath = "";
    selectedElementPath = getPathTo(currentElement);

    if ($(elem)[0].tagName == "BODY") {
        return "";
    } else {
        elem = $(elem);
        if (elem.find(selectedElementPath).length > 1) {
            var getUPath = getUniquePath($(elem)[0]);
            return getUPath;
        } else {
            return getParentIdClassNameIfFoundMore(elem.parent());
        }
    }

}

/*getting unique path fro the selected element*/
var getUniquePath = function(node) {

    var parts = [];

    var generatePath;
    if ($(node).parent().children().length > 1) {
        parts.push(node.tagName + ':nth-child(' + ($(node).index() + 1) + ')');
    } else {
        parts.push(node.tagName);
    }
    $(node).parents().each(function(index, element) {
        if (element.tagName == "BODY") {
            parts.push(element.tagName);
            generatePath = parts.join(' > ', parts.reverse());
            return generatePath;
        } else {
            if ($(element).parent().children().length > 1) {
                parts.push(element.tagName + ':nth-child(' + ($(element).index() + 1) + ')');
            } else {
                parts.push(element.tagName);
            }
        }
    });

    return generatePath;
}

//##########ends selector path and unique paths//

/*page level label creation  */
function createLabelsStep2(obj, currentMatchIndex, type) {
    if (type == "links") {
        $('#labelsContainer').append('<span class="label" id="span' + obj.labelIndex + '" data-obj=""><span class="txt">' + assetToAdd + "  " + "Detail Url" + '</span><span class="edit">E</span><span class="delete">x</span></span>');

    } else {
        $('#labelsContainer').append('<span class="label" id="span' + obj.labelIndex + '" data-obj=""><span class="txt">' + obj.name + '</span><span class="edit">E</span><span class="delete">x</span></span>');
    }


    $("#span" + obj.labelIndex).css("position", "absolute");
    $("#span" + obj.labelIndex).css("left", $(obj.trainingElement).offset().left);
    $("#span" + obj.labelIndex).css("top", $(obj.trainingElement).offset().top);
    $("#span" + obj.labelIndex + " .delete").attr("data-index", obj.labelIndex);
    $("#span" + obj.labelIndex + " .edit").attr("data-index", obj.labelIndex);
    selectedAssetType = $("#assetType").val();
    selectedAssetSubType = $("#cntnr #assetSubType").val();

    $("#span" + obj.labelIndex + " .delete").attr("data-fieldType", selectedAssetType + "---" + selectedAssetSubType);
    currentMatchIndexInUIHandler = currentMatchIndex;
    $("#span" + obj.labelIndex + " .edit").bind("click", function(e) {
        editIndex = $(e.target).attr("data-index");
        id = $(e.target).parent().attr("id");
        editClicked = true;
        changeTab(1);

        iframe.contentWindow.postMessage([
            'Edit', editIndex, currentMatchIndexInUIHandler
        ], '*');
    })
    $("#span" + obj.labelIndex + " .delete").bind("click", function(e) {

        var confirmFromUser = confirm("Are you sure to delete the mapped item?");
        if (confirmFromUser) {
            var assetType = $(e.target).attr("data-fieldType").split("---");
            $(e.target).parent().remove();
            var len_ = assetTypeObject.length;
            for (var i = 0; i < len_; i++) {
                if ((assetTypeObject[i][0] == assetType[0]) && (assetTypeObject[i][1] == assetType[1])) {
                    assetTypeObject.splice(i, 1);
                    break;
                }
            }
            index = $(e.target).attr("data-index")
            iframe.contentWindow.postMessage([
                'Remove', index, currentMatchIndex
            ], '*');

        }
    });
}
//##############   ends page level label creation  //


function createlabels(data, currentMatchIndex) {
    refreshedit = true;
    if (data.actualUrl == window.location.href.split("?action=")[0]) {
        for (var i = 0; i < data.fields.length; i++) {
            createLabelsStep2(data.fields[i], currentMatchIndex, "fields");
        }
        for (var i = 0; i < data.links.length; i++) {
            createLabelsStep2(data.links[i], currentMatchIndex, "links");
        }

        labelIndex = data.links.length + data.fields.length;
    }
}

function updateSelectorVal(target) {
    var path = getPathTo(target);
    var parentPath = getParentIdClassNameIfFoundMore(target);

    var _path = parentPath + " " + path;

    if ($.inArray(_path, multipleSelector) == -1 || multipleSelector.length == 0) {
        multipleSelector.push(_path);
    }

    if (multipleSelector.length > 1) {
        finalSelector = multipleSelector.join(", ");
    } else {
        finalSelector = multipleSelector[0];
    }
}

/* right Click for an element*/
function rightClick(e) {
    e.preventDefault();
    e.stopPropagation();

    editClicked = false;
    currentElement = e.target;
    fullpath = getUniquePath(currentElement);
    if ($(e.target).parents('.window').length > 0) {} else
    if ($(e.target).parents('#cntnr').length > 0) {} else
    if ($(e.target).parents('.label').length > 0) {} else
    if ($(e.target).attr('id') == "cntnr") {} else
    if ($(e.target).attr('class') == "label") {} else
    if ($(e.target).attr('id') == "collapse-right") {} else
    if ($(e.target).parents('#l1').length > 0) {} else
    if ($(e.target).parents('.messenger').length > 0) {} else
    if ($(e.target).attr('class') == "messenger") {} else
    if ($(e.target).parents('#collapse-right').length > 0) {} else {

        $("#devMode").show();
        if (paginationInActive) {
            fullpath = getUniquePath(currentElement);
            $("#selectorVal").val(fullpath);
            $("#div_Scheme1").hide();
            $("#ok").text("Track Pagination");
            return;
        }

        if (assetIdMappingInProgress || assetTitleMappingInProgress) {
            finalSelector = "";
            finalSelector = getUniquePath(e.target);
        } else {

            updateSelectorVal(e.target);


        }
        content = $(e.target).text();
        elementTreeHasImage = checkElementHasImage(currentElement);
        if (elementTreeHasImage != true) {
            elementTreeHasA = checkElementHasA(currentElement);
        }

        $("#cntnrMap").empty();
        $('#attributeTxt').empty();
        $("#resultOutput").empty();
        $("#actionElem").val("");

        var checkAssetType = $('#assetType').val();
        if (checkAssetType !== 'select') {
            $("#assetSubType").focus();
        }

        checkElementType();

        highlightElements(typeOfElement);

        $("#selectorVal").val(finalSelector.trim());
    }
};

var urlPatterns = (localStorage.getItem("urlPatterns") != null) ? JSON.parse(localStorage.getItem("urlPatterns")).p : [];

var typeOfElement = "link"; // "text", "image"
function checkElementType() {
    if (elementTreeHasImage == true) {

        typeOfElement = "image";
        $("#linksOrFieldsDropdown").val("images");
        $("#assetSubType").val("image");

        $("#functionWraper").hide();
        $(".splitWraper").hide();
        $("#div_Scheme").hide();
        if (!paginationInActive) {
            $("#div_Scheme1").show();
        }
    } else if (elementTreeHasA == true) {
        typeOfElement = "link";
        $("#linksOrFieldsDropdown").val("links");
        $("#assetSubType").val("url");

        $("#functionWraper").hide();
        $(".splitWraper").hide();
        $("#div_Scheme").hide();
        if (!paginationInActive) {
            $("#div_Scheme1").show();
        }
    } else {
        typeOfElement = "text";
        $("#linksOrFieldsDropdown").val("fields");
        $("#functionWraper").show();
        //$("#div_Scheme").show();
        if (!paginationInActive) {
            $("#div_Scheme1").show();
        }
    }
}


function highlightElements(type) {
    stringDisplay = "";
    $("#cntnr #resultOutput").html("");
    //var attributeStr = "";
    var urlValues = [];
    try {
        $(finalSelector.trim()).each(function() {
            $(this).addClass(" class-highlighter");
            if (type == "link") {
                urlValues.push($(this).prop('href'));
            }
        });
        if (urlValues.length > 0) {
            urlPatterns.push(generateUrlPattern(urlValues, 3));
            localStorage.setItem("urlPatterns", JSON.stringify({
                p: urlPatterns
            }));
        }
    } catch (e) {}
}

/* url pattern generation*/
function generateUrlPattern(urlValues, index, urlPatternString = "") {


    if (typeof urlValues[0] == "string") {
        for (i = 0; i < urlValues.length; i++) {
            urlValues[i] = urlValues[i].split('/');
        }
    }
    var array = [];
    var urlPattern = (urlPatternString != "") ? urlPatternString : urlValues[0][0] + "/" + urlValues[0][1] + "/" + urlValues[0][2] + "/";

    var elementVal = urlValues[0][index]; // shows
    var urlPatternFinalized = false;

    for (i = 1; i < urlValues.length; i++) {
        if (urlValues[i][index] != elementVal) {
            urlPattern += ".*";
            array = urlPattern
            //console.log("urlPattern" + array);
            urlPatternFinalized = true;
            break;
        }
    }

    if (!urlPatternFinalized) {
        urlPattern += elementVal + "/";
        generateUrlPattern(urlValues, index + 1, urlPattern);
    }
    return urlPattern;

}
//### ends url generation


function getAttrName(str) {
    var firstIndex = str.lastIndexOf("[");
    var lastIndex = str.lastIndexOf("]");
    return str.substring(firstIndex + 1, lastIndex).split("=")[0];
}


//disableAllEventsOnThePage();
function disableAllEventsOnThePage() {
    $("a").click(function(e) {
        e.preventDefault();
    });
}

// check if element has href and return//
function fetchHrefAttr(elem) {
    hrefAttributes = [];

    if ($(elem).hasAttr("href")) {
        hrefAttributes.push({
            "name": "href",
            "value": $(elem).attr("href")
        });
        return true;
    } else {

        for (var i = 0; i < elem.attributes.length; i++) { // check if element has href similar and return
            if (elem.attributes[i].name.indexOf("href") > -1) {
                hrefAttributes.push({
                    "name": elem.attributes[i].name,
                    "value": elem.attributes[i].value
                });
            }
        }
        if (hrefAttributes.length > 0) {
            return true;
        } else {
            var allChildElements = $(elem).find('*');
            for (var i = 0; i < allChildElements.length; i++) {
                var attrs = allChildElements[i].attributes;

                // check if it has href

                if ($.inArray("href", attrs)) {
                    hrefAttributes.push({
                        "name": "href",
                        "value": $(allChildElements[i]).attr("href")
                    });
                } else {
                    for (var j = 0; j < attrs.length; j++) {
                        if (attrs[j].name.indexOf("href") > -1) {
                            hrefAttributes.push({
                                "name": attrs[j].name,
                                "value": attrs[j].value
                            });
                        }
                    }
                }
            }
            if (hrefAttributes.length > 0) {
                return true;
            } else {
                fetchHrefAttr($(elem).parent()[0]);
            }
        }

    }

}

if (typeof(Storage) !== "undefined" || typeof(Storage) !== null) {
    localStorage.setItem("trainingUrlTracked", "false"); // Verify the use of this var
} else {
    // Sorry! No Web Storage support..
}



/* Adding links and fields attributes and updates Json object */
$("#ok").click(function() {

    var assetSubValue = $("#cntnr #assetSubType").val();
    dropdownValue = $("#linksOrFieldsDropdown").val();

    if (assetSubValue !== 'select' || paginationInActive) {

        $("#div_Scheme1").show();
        $("#ok").text("Add Attribute");
        $(".class-highlighter-yellow").removeClass("class-highlighter-yellow");
        assetToAdd = pageObj[0].assets[currentAssetIndex].assetTitle;

        if (paginationInActive) {
            $("#subSessionContent").append('<div id="ssLabels_' + labelIndex + '">' + assetToAdd + " " + "pagination " + '</div>')
        } else {
            if ($("#linksOrFieldsDropdown").val() == "links") {
                if (editClicked == false && assetSubValue != 'asset Id') {
                    $("#subSessionContent").append('<div id="ssLabels_' + labelIndex + '">' + assetToAdd + " " + assetSubValue + '</div>')
                }

            } else {
                if (editClicked == false && assetSubValue != 'asset Id') {
                    $("#subSessionContent").append('<div id="ssLabels_' + labelIndex + '">' + assetToAdd + " " + assetSubValue + '</div>')
                } else {
                    $("#ssLabels_" + editIndex).text(assetSubValue);
                }
            }
        }


        if (editClicked == false) {
            checkEditClicked(false,dropdownValue);
        }

        $("#devMode").hide();
        iframe.contentWindow.postMessage([
            'updatePageObj', pageObj
        ], '*');

        fieldObj = {
            "trainingElement": "",
            "assetType": "",
            "assetTypeId": "",
            "attributeId": "",
            "name": "",
            "attribute": "",
            "type": "",
            "id": "",
            "value": "",
            "labelIndex": labelIndex,
            "actions": [],
            "function": {
                "name": "",
                "multiOut": "",
                "parameters": {
                    "param1": "",
                    "param2": ""
                },
                "fields": []
            }
        };

        linkObj = {
            "trainingElement": "",
            "assetType": "",
            "assetTypeId": "",
            "attributeId": "",
            "name": "",
            "attribute": "href",
            "value": "",
            "type": "css selector",
            "id": "",
            "actions": [],
            "labelIndex": labelIndex
        };
        checklinkOrField(dropdownValue)

          /*  edit functionality  for matches*/
        if (editClicked == true) {
          checkEditClicked(true,dropdownValue);
        } else if ($("#selectorVal").val() != "") {
            if (localStorage.getItem("trainingUrlTracked") === "false") {
                localStorage.setItem("trainingUrlTracked", "true"); // set this to false when that item label is deleted, remove trainingUrl
            }
            iframe.contentWindow.postMessage([
                'addMatch', window.location.href, JSON.parse(localStorage.getItem("urlPatterns"))
            ], '*');
            schemaName = $("#cntnr .schemaName").val();

            /* label creation in configuration tab*/
            if ($("#linksOrFieldsDropdown").val() == "links" && $("#cntnr #assetSubType").val() != "asset Id") {
                $('#labelsContainer').append('<span class="label" id="span' + labelIndex + '" data-obj=""><span class="txt">' + assetToAdd + "  " + $("#cntnr #assetSubType").val() + '</span><span class="edit">E</span><span class="delete">x</span></span>');
            } else if ($("#linksOrFieldsDropdown").val() == "fields" && $("#cntnr #assetSubType").val() != "asset Id") {
                $('#labelsContainer').append('<span class="label" id="span' + labelIndex + '" data-obj=""><span class="txt">' + assetToAdd + "  " + $("#cntnr #assetSubType").val() + "  " + '</span><span class="edit">E</span><span class="delete">x</span></span>');
            } else if ($("#linksOrFieldsDropdown").val() == "images" && $("#cntnr #assetSubType").val() != "asset Id") {
                $('#labelsContainer').append('<span class="label" id="span' + labelIndex + '" data-obj=""><span class="txt">' + assetToAdd + "  " + $("#cntnr #assetSubType").val() + "  " + '</span><span class="edit">E</span><span class="delete">x</span></span>');
            }


            $("#span" + labelIndex).css("background-color", "rgba(0, 0, 0, 0.65);");
            $("#span" + labelIndex).css("left", $(currentElement).offset().left);
            $("#span" + labelIndex).css("top", $(currentElement).offset().top); // + $(currentElement).height() //- $(currentElement).prop('scrollHeight')
            //$("#span" + labelIndex).attr("data-obj", "schemaName="+"xx"+";selector="+"yy");
            $("#span" + labelIndex + " .delete").attr("data-index", labelIndex);
            $("#span" + labelIndex + " .edit").attr("data-index", labelIndex);

            selectedAssetType = $("#assetType").val();
            selectedAssetSubType = $("#assetSubType").val();

            $("#span" + labelIndex + " .delete").attr("data-fieldType", selectedAssetType + "---" + selectedAssetSubType);

            $(".class-highlighter").removeClass("class-highlighter");

            $("#span" + labelIndex + " .edit").bind("click", function(e) {
                $("#devMode").show();
                editIndex = $(e.target).attr("data-index");
                id = $(e.target).parent().attr("id");
                editClicked = true;
                changeTab(1)
                iframe.contentWindow.postMessage([
                    'Edit', editIndex, null
                ], '*');
            });
            //ends edit //
            /* deletes created labels from page level,configuration tab and from json object*/
            $("#span" + labelIndex + " .delete").bind("click", function(e) {

                var confirmFromUser = confirm("Are you sure to delete the mapped item?");

                if (confirmFromUser) {

                    var assetType = $(e.target).attr("data-fieldType").split("---");
                    $(e.target).parent().remove();
                    editIndex = $(e.target).attr("data-index");
                    $("#ssLabels_" + editIndex).remove();
                    var len_ = assetTypeObject.length;
                    for (var i = 0; i < len_; i++) {
                        if ((assetTypeObject[i][0] == assetType[0]) && (assetTypeObject[i][1] == assetType[1])) {
                            assetTypeObject.splice(i, 1);
                            break;
                        }
                    }

                    iframe.contentWindow.postMessage([
                        'Remove', $(e.target).attr("data-index"), null
                    ], '*');

                }
            });
            //ends delete//
            assetTypePush();
            bindLinkOrField(dropdownValue);

            $('#assetSubType').val('select');
            $('#linksOrFieldsDropdown').val('links');
            $(".splitWraper").hide();
            $("#SplitError").hide();
            $('#selectorVal').val('');
            $('#actionType').val('select');
            $('a').unbind("click.myDisable");
            $('#loginActionType').val('select');
            $('#loginActionElem').val('');
            labelIndex++;
        }

        localStorage.setItem("pageObj", JSON.stringify(pageObj));
        multipleSelector = [];
    } else {
        Messenger().post("Please select attribute name before adding");
    }
});
// checks edit click is true or false//
function checkEditClicked(editClicked,dropdownValue){
  if (editClicked == false) {
      $("DIV[id^='ssLabels_']").bind("mouseover", function(e) {
          var index = $(e.target).attr("id").split("ssLabels_")[1];
          $("#span" + index).addClass("class-highlighter");
      });
      $("DIV[id^='ssLabels_']").bind("mouseout", function(e) {
          var index = $(e.target).attr("id").split("ssLabels_")[1];
          $("#span" + index).removeClass("class-highlighter");
      });
  }
  else if (editClicked == true){
    assetType = $("#assetType").val();
    value = $("#selectorVal").val();
    if (dropdownValue == "fields") {
        name = $("#cntnr #assetSubType").val();
        var ii = $('#' + id).find(".txt");
        $(ii).text(name);
    } else {
        name = "";
    }
    //Update matches
      iframe.contentWindow.postMessage([
          'updateMatch', window.location.href, assetType, name, value, dropdownValue, editIndex, currentMatchIndexInUIHandler
      ], '*');
  }

}
//map links and fields to respective objects//
function checklinkOrField(dropdownValue){
  if (dropdownValue == "fields" || dropdownValue == "images") {

      fieldObj.assetType = $("#assetType").val();
      fieldObj.name = $("#assetSubType").val();
      fieldObj.type = "css selector";
      fieldObj.value = $("#selectorVal").val();

      fieldObj.labelIndex = labelIndex;


      if (assetIdMappingInProgress || assetTitleMappingInProgress) {
          fieldObj.name = "asset Id";
          fieldObj.attribute = "";
      }
      if ($('#assetSubType').val() == "image") {
          fieldObj.attribute = "src";
      } else if ($('#assetSubType').val() == "url") {
          fieldObj.attribute = "href";
      } else {
          fieldObj.attribute = "";
      }

      if (assetIdMappingInProgress) {
          $("#AssetIdSelectorVal").val($("#selectorVal").val());
      }

      if (assetTitleMappingInProgress) {
          fieldObj.name = "title";
          $("#AssetTitleSelectorVal").val($("#selectorVal").val());
      }

      fieldObj.trainingElement = fullpath;

      //action click start
      actionObject.action = $("#actionType").val();
      actionObject.value = $("#actionElem").val();

      if ($("#linksOrFieldsDropdown").val() == "fields" && $("#actionElem").val() !== "" && $("#actionType").val() == "click") {
          fieldObj.actions.push(actionObject);
      }
      //action click end

      if ($("#linksOrFieldsDropdown").val() == "fields" && $("#actionType").val() == "scroll") {
          actionObject.action = "Scrolldown";
          fieldObj.actions.push(actionObject);
      }

  } else {

      linkObj.value = $("#selectorVal").val();
      linkObj.name = $("#assetSubType").val();
      linkObj.trainingElement = fullpath;


      if ($("#linksOrFieldsDropdown").val() == "links" && $("#actionElem").val() !== "" && $("#actionType").val() == "click") {
          linkObj.actions.push(actionObject);
      }
      if ($("#linksOrFieldsDropdown").val() == "links" && $("#actionType").val() == "scroll") {
          actionObject.action = "Scrolldown";
          linkObj.actions.push(actionObject);

      }

      if (assetIdMappingInProgress || assetTitleMappingInProgress) {
          linkObj.name = "asset Id";
          linkObj.attribute = "";
      }

      if ($('#assetSubType').val() == "image") {
          linkObj.attribute = "src";
      } else if ($('#assetSubType').val() == "url") {
          linkObj.attribute = "href";
      } else {
          linkObj.attribute = "";
      }

      if (assetIdMappingInProgress) {
          $("#AssetIdSelectorVal").val($("#selectorVal").val());
      }

      if (assetTitleMappingInProgress) {
          linkObj.name = "title";
          $("#AssetTitleSelectorVal").val($("#selectorVal").val());
      }

      if (paginationInActive) {
          linkObj.paginate = true;
          linkObj.attribute="href"; 
      } else if (scrollPaginationInActive) {
          // add scroll pagination code here
      }

  }
}
/* based on linksOrFieldsDropdown value adding links or fields or images:posting message to extn*/
        function bindLinkOrField(dropdownValue){

              if ($("#linksOrFieldsDropdown").val() == "links") {
                  iframe.contentWindow.postMessage([
                      'addLink', linkObj
                  ], '*');
              } else if ($("#linksOrFieldsDropdown").val() == "fields") {
                  fieldObj.attribute = "";
                  iframe.contentWindow.postMessage([
                      'addField', fieldObj
                  ], '*');

              } else if ($("#linksOrFieldsDropdown").val() == "images") {
                  fieldObj.attribute = "src";
                  iframe.contentWindow.postMessage([
                      'addField', fieldObj
                  ], '*');

              }
}
//binding assetTypeId and attributeId
var assetTypeId = "";
$("#assetType").change(function() {

    var assetTypeId = $('#assetType option:selected').attr('data-assettypeid');
    var assetType = $('#assetType').val();
    fieldObj.assetTypeId = assetTypeId;
    fieldObj.assetType = assetType;
    linkObj.assetTypeId = assetTypeId;
    linkObj.assetType = assetType;


});

var attributeId = "";
$(".assetSubType").change(function() {

    var attributeId = $('.assetSubType option:selected').attr('data-attributeId');
    fieldObj.attributeId = attributeId;
    linkObj.attributeId = attributeId;
    //linkObj.name=$("#cntnr #assetSubType").val();

});


var loginFlowComplete = false;

$("#close,#iconClose").click(function() {
    $('#validateModal').modal('hide');
});



$('#assetSubType').change(function() {

});

/*Mapping functions  starts*/
$('.fnDropdown').bind('change', function() {
    selectedFn = $(".fnDropdown").find("option:selected").text();
    if (selectedFn == "Select a function") {
        $("#delimiterWrapper").hide();
        $(".splitWraper").hide();
        $("#subSrtingWraper").hide();
        $("#SplitError").hide();
    }
    fnDropdown();
});

function fnDropdown() {

    selectedFn = $(".fnDropdown").find("option:selected").text();
    if (selectedFn == "Select a function") {
        fieldObj.function.name = "";
    }
    //code for split function
    if (selectedFn == "split") {

        $('<br/><div id="delimiterWrapper"><span class="formLabel">Delimiter:</span><input id="delimiter" name="input[]"  type="text"></input></div>').insertAfter(".fnDropdown");
        var string, delimiter;

        $('#delimiter').change(function(e) {
            delimiter = $("#delimiter").val();
            //console.log(delimiter);
            $("#SplitError").hide();
            //console.log("content is this selected" + content);
            stringContent = content.trim(); // remove multiple spaces in between

            fieldObj.function.parameters.param1 = stringContent;
            fieldObj.function.parameters.param2 = delimiter;

            if (delimiter.length !== 0 && delimiter !== "undefined" && delimiter !== null) {
                var postData = {
                    string: stringContent,
                    delimeter: delimiter
                };

                fieldObj.function.name = selectedFn;


                $.ajax(domainUrl + "/vcrawler/functions/split/", {
                    type: 'GET',
                    crossDomain: true,
                    ContentType: "application/json; charset=UTF-8",
                    data: postData,
                    success: function(response) {
                        response = eval(response);
                        //alert(response['output']);
                        var length = response['output'].length;


                        if (length > 1) fieldObj.function.multiOut = selectedFn;
                        if (response['output'] == "split function can't be applied") {
                            $(".ok").css('opacity', '0.6');
                            $(".ok").prop("disabled", true);
                            $('<div id="SplitError" style=color:red;>Split function can not be applied on this element.</div>').insertAfter("#delimiterWrapper");
                        } else {
                            $(".ok").css('opacity', '1.0');
                            for (var i = 0; i < length; i++) {
                                $('<div id="' + i + '" class="splitWraper" style="margin-top:3px;"><select class="test" id="splituserval' + i + '" name="input[]"  type="text" style="width:100px; margin-right:5px;"></select><input id="splitdata' + i + '" class="splitDisabled" style="width:100px" value="' + response['output'][i] + '"></input></div>').insertAfter("#functionBlock");
                                $(".splitDisabled").prop('disabled', true);

                                fieldObj.function.fields.push({
                                    "name": "",
                                    "index": i
                                });

                            }
                        }
                        $(".assetSubType option").clone(true).appendTo("select.test");

                        $("select.test").bind('change', function() {
                            fieldObj.function.fields[$(this).parent().attr("id")].name = $(this).val();
                            // console.log("ashdgajdkhsgjhgeqwyegqwyqwyegwquyeg"+$(this).val());
                        });

                        $(".assetType").bind('change', function() {
                            $('select.test option').remove();
                            $(".assetSubType option").clone(true).appendTo("select.test");
                        });
                    }
                });



            }
        });
    }


}
// ends mapping functions

$(document).ready(function() {
    populateAsset();
    setTimeout(function() {
        $('body').append($('.messenger'));
    }, 1000);
    // post a roviMsg with window url
});



$(window).ready(function() {
    setTimeout(function() {
        iframe.contentWindow.postMessage([
            'currentPageUrl', window.location.href
        ], '*');
    }, 500);
});


/* binding values to Asset type dropdown */
function populateAsset() {

    $.ajax({
        type: "GET",
        url: domainUrl + "/tivo_spider/get_field/", //url:"http://172.26.119.65:8000/tivo_spider/get_field/",
        dataType: "json",
        success: function(data) {
            result = data;
            for (var i = 0; i < data.assets.length; i++) {
                var div_data = "<option value=" + data.assets[i].name + " data-assettypeid=" + data.assets[i].assetTypeID + ">" + data.assets[i].name + "</option>";
                $(div_data).appendTo('.assetType');

            }
            $('#assetType').bind('change', function(e) {
                selectedAssetType = $('.assetType').val();
                $('.assetSubType option').not(':first').remove();
                var test = document.getElementById("assetType").selectedIndex;
                for (var i = 0; i < data.assets.length; i++) {
                    if (data.assets[i].name == selectedAssetType) {
                        for (var j = 0; j < data.assets[i].fields.length; j++) {
                            div_data1 = "<option value='" + data.assets[i].fields[j][0] + "' data-attributeId='" + data.assets[i].fields[j][1] + "'>" + data.assets[i].fields[j][0] + "</option>";
                            $(div_data1).appendTo('.assetSubType');
                        }

                    }

                }

            });


        }
    });

}
//ends binding values to Asset type dropdown


//hide and show for function wrapper on dropdown select.
$("#linksOrFieldsDropdown").bind('change', function() {
    if ($("#linksOrFieldsDropdown").val() == "fields") {} else {
        $(".splitWraper").hide();
    }
});


var windows = document.querySelectorAll('.window');
[].forEach.call(windows, function(win) {
    var title = win.querySelector('.titlebar');
    title.addEventListener('mousedown', function(evt) {

        // Record where the window started
        var real = window.getComputedStyle(win),
            winX = parseFloat(real.left),
            winY = parseFloat(real.top);

        // Record where the mouse started
        var mX = evt.clientX,
            mY = evt.clientY;

        // When moving anywhere on the page, drag the window
        // …until the mouse button comes up
        document.body.addEventListener('mousemove', drag, false);
        document.body.addEventListener('mouseup', function() {
            document.body.removeEventListener('mousemove', drag, false);
        }, false);

        // Every time the mouse moves, we do the following
        function drag(evt) {
            // Add difference between where the mouse is now
            // versus where it was last to the original positions
            win.style.left = winX + evt.clientX - mX + 'px';
            win.style.top = winY + evt.clientY - mY + 'px';
        };
    }, false);
});

// modal window //
var modal = document.getElementById('userModalPopup');
var validateModal = document.getElementById('userModalPopup1');

var btnClose = document.getElementById("btnClose");
var btnCloseTop = document.getElementById("btnCloseTop");

btnClose.onclick = function() {
    modal.style.display = "none";
}
btnCloseTop.onclick = function() {
    modal.style.display = "none";
}


selectedAssetType = "";
selectedAssetSubType = "";

function assetTypePush() {
    selectedAssetType = $("#assetType").val();
    selectedAssetSubType = $("#assetSubType").val();

    if (selectedAssetType !== "select" && selectedAssetType !== "") {
        assetTypeObject.push([selectedAssetType, selectedAssetSubType]);
    }
}
/* if asset Type changes*/
$("#div_Scheme").bind('change', function() {
    selectedAssetType = $("#assetType").val();
    if ($.inArray(selectedAssetType, assetTypeObject[selectedAssetType]) < 0) {
        $("#assetType").removeClass(".error");
        $(".ok").prop("disabled", false);
        $(".ok").css('opacity', '1.0');
    } else {
        $("#assetType").addClass(".error");
        $(".ok").prop("disabled", true);
        $(".ok").css('opacity', '0.6');
        Messenger().post("Selected combination is already defined in schema.");
    }
});


$("#div_Scheme1").bind('change', function() {
    selectedAssetType = $("#assetType").val();
    selectedAssetSubType = $("#assetSubType").val();
    var fieldAlreadyMaped = false;
    var len = assetTypeObject.length;
    for (var i = 0; i < len; i++) {
        if ((assetTypeObject[i][0] == selectedAssetType) && (assetTypeObject[i][1] == selectedAssetSubType)) {
            fieldAlreadyMaped = true;
            break;
        }
    }
    if (fieldAlreadyMaped == false) {
        $("#assetSubType").removeClass(".error");
        $(".ok").prop("disabled", false);
        $(".ok").css('opacity', '1.0');
    } else {
        $("#assetSubType").addClass(".error");
        $(".ok").prop("disabled", true);
        $(".ok").css('opacity', '0.6');
        Messenger().post("Selected combination is already defined in schema.");
    }
});
//assetType check logic End


//Action logic start
$("#actionType").bind('change', function() {
    var selectedFAction = $("#actionType").find("option:selected").val();
    if (selectedFAction == "click") {
        $("*").click(function(e) {
            if (!$(e.target).parents().is('#cntnr') && !$(e.target).is('.stepNumber')) {
                var elms = getPathTo(e.target);
                var elms1 = elms.startsWith(".");
                $('#actionElem').val("");
                if (elms.startsWith(".")) {
                    var elms1 = "[class^='" + elms.substring(1) + "']";
                    $('#actionElem').val(elms1);
                } else if (elms.startsWith("#")) {
                    var elms1 = "[id*='" + elms.substring(1) + "']";
                    $('#actionElem').val(elms1);
                }
            }
            $('#actionElem').show();
            $('#elementwrapper').show();
        });
    }

    if (selectedFAction == "scroll" || selectedFAction == "select") {
        $('#actionElem').val('');
        $('#elementwrapper').hide();
    }
});

//change for login start
$(document).ready(function() {
    populateAsset();
    setTimeout(function() {
        $('body').append($('.messenger'));
    }, 1000);
    // post a roviMsg with window url
});


$(window).ready(function() {
    setTimeout(function() {
        iframe.contentWindow.postMessage([
            'currentPageUrl', window.location.href
        ], '*');
    }, 500);
});


/* binding values to asset type dropdown from API */
function populateAsset() {

    $.ajax({
        type: "GET",
        url: domainUrl + "/tivo_spider/get_field/", //url:"http://172.26.119.65:8000/tivo_spider/get_field/",
        dataType: "json",
        success: function(data) {
            result = data;
            for (var i = 0; i < data.assets.length; i++) {
                var div_data = "<option value=" + data.assets[i].name + " data-assettypeid=" + data.assets[i].assetTypeID + ">" + data.assets[i].name + "</option>";
                $(div_data).appendTo('.assetType');

            }
            $('#assetType').bind('change', function(e) {
                selectedAssetType = $('.assetType').val();
                $('.assetSubType option').not(':first').remove();
                var test = document.getElementById("assetType").selectedIndex;
                //console.log(selectedAssetType);
                for (var i = 0; i < data.assets.length; i++) {
                    if (data.assets[i].name == selectedAssetType) {
                        for (var j = 0; j < data.assets[i].fields.length; j++) {
                            div_data1 = "<option value='" + data.assets[i].fields[j][0] + "' data-attributeId='" + data.assets[i].fields[j][1] + "'>" + data.assets[i].fields[j][0] + "</option>";
                            $(div_data1).appendTo('.assetSubType');
                        }

                    }

                }

            });


        }
    });

}

//hide and show for function wrapper on dropdown select.
$("#linksOrFieldsDropdown").bind('change', function() {
    if ($("#linksOrFieldsDropdown").val() == "fields") {} else {
        $(".splitWraper").hide();
    }


});


var windows = document.querySelectorAll('.window');
[].forEach.call(windows, function(win) {
    var title = win.querySelector('.titlebar');
    title.addEventListener('mousedown', function(evt) {

        // Record where the window started
        var real = window.getComputedStyle(win),
            winX = parseFloat(real.left),
            winY = parseFloat(real.top);

        // Record where the mouse started
        var mX = evt.clientX,
            mY = evt.clientY;

        // When moving anywhere on the page, drag the window
        // …until the mouse button comes up
        document.body.addEventListener('mousemove', drag, false);
        document.body.addEventListener('mouseup', function() {
            document.body.removeEventListener('mousemove', drag, false);
        }, false);

        // Every time the mouse moves, we do the following
        function drag(evt) {
            // Add difference between where the mouse is now
            // versus where it was last to the original positions
            win.style.left = winX + evt.clientX - mX + 'px';
            win.style.top = winY + evt.clientY - mY + 'px';
        };
    }, false);
});

// modal window //
var modal = document.getElementById('userModalPopup');
var validateModal = document.getElementById('userModalPopup1');

var btnClose = document.getElementById("btnClose");
var btnCloseTop = document.getElementById("btnCloseTop");

btnClose.onclick = function() {
    modal.style.display = "none";
}
btnCloseTop.onclick = function() {
    modal.style.display = "none";
}


selectedAssetType = "";
selectedAssetSubType = "";

function assetTypePush() {
    selectedAssetType = $("#assetType").val();
    selectedAssetSubType = $("#assetSubType").val();

    if (selectedAssetType !== "select" && selectedAssetType !== "") {
        assetTypeObject.push([selectedAssetType, selectedAssetSubType]);
    }
}

$("#div_Scheme").bind('change', function() {
    selectedAssetType = $("#assetType").val();
    if ($.inArray(selectedAssetType, assetTypeObject[selectedAssetType]) < 0) {
        $("#assetType").removeClass(".error");
        $(".ok").prop("disabled", false);
        $(".ok").css('opacity', '1.0');
    } else {
        $("#assetType").addClass(".error");
        $(".ok").prop("disabled", true);
        $(".ok").css('opacity', '0.6');
        Messenger().post("Selected combination is already defined in schema.");
    }
});


$("#div_Scheme1").bind('change', function() {
    selectedAssetType = $("#assetType").val();
    selectedAssetSubType = $("#assetSubType").val();
    var fieldAlreadyMaped = false;
    var len = assetTypeObject.length;
    for (var i = 0; i < len; i++) {
        if ((assetTypeObject[i][0] == selectedAssetType) && (assetTypeObject[i][1] == selectedAssetSubType)) {
            fieldAlreadyMaped = true;
            break;
        }
    }
    if (fieldAlreadyMaped == false) {
        $("#assetSubType").removeClass(".error");
        $(".ok").prop("disabled", false);
        $(".ok").css('opacity', '1.0');
    } else {
        $("#assetSubType").addClass(".error");
        $(".ok").prop("disabled", true);
        $(".ok").css('opacity', '0.6');
        Messenger().post("Selected combination is already defined in schema.");
    }
});
//assetType check logic End


/*Action logic start */
$("#actionType").bind('change', function() {
    var selectedFAction = $("#actionType").find("option:selected").val();
    if (selectedFAction == "click") {
        $("*").click(function(e) {
            if (!$(e.target).parents().is('#cntnr') && !$(e.target).is('.stepNumber')) {
                var elms = getPathTo(e.target);
                var elms1 = elms.startsWith(".");
                $('#actionElem').val("");
                if (elms.startsWith(".")) {
                    var elms1 = "[class^='" + elms.substring(1) + "']";
                    $('#actionElem').val(elms1);
                } else if (elms.startsWith("#")) {
                    var elms1 = "[id*='" + elms.substring(1) + "']";
                    $('#actionElem').val(elms1);
                }
            }
            $('#actionElem').show();
            $('#elementwrapper').show();
        });
    }

    if (selectedFAction == "scroll" || selectedFAction == "select") {
        $('#actionElem').val('');
        $('#elementwrapper').hide();
    }
});



var traceLoginUrl = "",
    loginElms = "",
    localStorePostActions = "",
    firstUrl = "";
preActionCount = 0;
//change for login start
function createLoginSubSession() {
    changeTab(4);
    $("#loginTrackBtn").bind('click', function() {

        loginFlowComplete = false;
        var selectedFAction = "click"; //$("#loginActionType").find("option:selected").val();
        var lastClicked;
        var clickCount = 0;
        if (selectedFAction == "click") {
            $("*").click(function(e) {

                if (!$(e.target).parents().is('#cntnr') && !$(e.target).is('.tabs') && !$(e.target).is('#loginTrackBtn')) {
                    loginElms = getPathTo(e.target);

                    $(loginElms).bind('change', function(e) {
                        if ($(loginElms).attr('type') == "password") {
                            var capturPassword = $(loginElms).val();
                            signinObject.password.content = capturPassword;
                            captureLoginUnP(loginElms, "#loginActionElemP");
                        }
                        if ($(loginElms).attr('type') == "text" || $(loginElms).attr('type') == "email") {
                            var capturText = $(loginElms).val();
                            signinObject.userName.content = capturText;
                            captureLoginUnP(loginElms, "#loginActionElemU");
                        }


                    });

                    if (preActionCount == 0) {

                        captureLoginUnP(loginElms, "#loginActionElemPre");
                        preActionCount++;
                        $("#toggle1").trigger("click");

                    }

                    lastClicked = loginElms;

                    if (signinObject.password.content != "" && signinObject.userName.content != "" && clickCount == 0) {
                        clickCount++;
                        localStorePostActions = {
                            "url": window.location.href,
                            "action": "click",
                            "value": lastClicked,
                            "type": "css selector"
                        }
                        signinObject.postActions.push(localStorePostActions);
                        signinObject.preActions.push(JSON.parse(localStorage.getItem('localStorePreActions')));
                        localStorage.setItem('localStorePreActions', null);
                        iframe.contentWindow.postMessage([
                            'updaterootObject', signinObject
                        ], '*');

                        Messenger().post("Login details tracked successfully..! Please login to continue...");
                        changeTab(3);
                        $('#loginBlock').hide();
                    }
                }
                $('#elementwrapper').show();
            });
        }
    });

}

function captureLoginUnP(content, input) {
    if (content.startsWith(".")) {
        var elms1 = "[class^='" + content.substring(1) + "']";
    } else if (content.startsWith("#")) {
        var elms1 = "[id*='" + content.substring(1) + "']";
    }
    $(input).val(elms1);
    if (input == "#loginActionElemU") {
        signinObject.userName.value = elms1;
    } else if (input == "#loginActionElemP") {
        signinObject.password.value = elms1;
    } else if (input == "#loginActionElemPre") {
        localStorePreActions = {
            "url": window.location.href,
            "action": "click",
            "value": elms1,
            "type": "css selector"
        }
        localStorage.setItem('localStorePreActions', JSON.stringify(localStorePreActions));
    }
}
//change for login end
//Chrome extension tab//
var prevStepId = 1;

function changeTab(n) {
    $("#step-" + prevStepId + "-c").css("display", "none");
    $("#th" + prevStepId).removeClass("selected");
    $("#step-" + n + "-c").css("display", "block");
    $("#th" + n).addClass("selected");
    prevStepId = n;
}
$('.subsessionWidget .header').click(function() {
    $(this).next().toggle();
});
var currentAssetIndex = -1;

$("#addAsset").click(function() {
    $("#devMode").hide();
    $("#AssetIdSelectorVal").val('');
    $("#AssetTitleSelectorVal").val('');
    $("#subsessionbtn").empty();
    $("#subSessionContent").empty();
    $("#subSessionDone").hide();

    //$(".assetTypeLabels").empty();
    currentAssetIndex++;
    pageObj[0].assets.push({
        "assetTitle": $("#assetType").val(),
        "activeAsset": true,
        "currentSubSession": "listing",
        "roviCurrentQ": 1,
        "subSessions": {}
    });
    var assetsMapped = $("#assetTypeContainer").text();
    assetToAdd = $("#assetType").val();
    if (assetsMapped.indexOf(assetToAdd) < 0 && $("#assetType").val() != "select") {
        $("#assetTypeContainer").show();
        $("#div_Scheme").hide();
        $(".assetSSContainer").show();


        $("#assetTypeContainer .assetTypeLabels.active").removeClass("active");
        $("#subSessionContainer").hide();
        currentSelectedAsset = $(this).text();
        // change the current asset code
        var btn = $('<button/>', {
            text: $("#assetType").val(),
            class: 'assetTypeLabels active',
            click: function() {
                loadAssetDetails($(this).text());
                changeAssetTab();
            }
        });
        $("#assetTypeContainer").append(btn);
        roviCurrentQ++;
        throwMessage();

        $("#subSessionContainer .subSessionLabels.active").removeClass("active");
        var btn = $('<button/>', {
            text: "Attributes",
            class: 'subSessionLabels active',
            click: function() {

            }
        });
        $("#subsessionbtn").append(btn);
    } else {
        Messenger().post("Asset is already added or you have not selected any asset.");
    }

});

function changeAssetTab() {
    $('.assetTypeLabels').add('active')
        .toggleClass("assetTypeLabels").toggleClass("assetTypeLabels active");
}

function loadAssetDetails(str) {
    $("#assetDetails").find("legend").text(str);
}
