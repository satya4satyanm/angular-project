alert("ui JS loaded");

var src = chrome.extension.getURL("/src/views/iframe.html")
var iframeContainer = document.createElement('div');

var xyz= chrome.runtime.getURL("/src/resources/images/48.png");

iframeContainer.innerHTML = '<input id="toggle1" type="checkbox" checked=""><label id="l1" for="toggle1"><img src="'+xyz+'"/></label><div id="collapse-right"> <div id="wizard" class="swMain">  <ul class="anchor" style="margin: 0;padding: 0;">  <li id="th1" class="tabs" rel="1" onclick="changeTab(1)">Configuration</li>  <li id="th2" class="tabs" rel="2" onclick="changeTab(2)">Validation</li>  <li id="th3" class="tabs selected" rel="3" onclick="changeTab(3)">JSON</li> 	 <li id="th4" class="tabs" rel="4" onclick="changeTab(4)">Login</li>  </ul>  <div class="stepContainer">  <div id="step-1-c" class="content" style="display: none;height: 530px;padding-top:20px;">  <h2 class="StepTitle"></h2>  <div id="cntnr"> <button class="ok" id="start">Start Mapping</button><br/> What are you defining:   <select id="linksOrFieldsDropdown">  <option value="links">Links</option>  <option value="fields">Fields</option>  <option value="images">Images</option>  </select>  <br/>   <div id="div_Scheme">  Asset Type:   <select id="assetType" class="assetType" >  <option value="select">Select Asset Type</option>  </select>  <br/>  </div>  <div id="div_Scheme1">  Field Name:   <select id="assetSubType" class="assetSubType" >  <option value="select">Select Field Name</option>  </select>  <br/>  </div>  <div id="fieldsError" style="display:none; color:red;">Selected combination is already defined in schema.</div>  <div id="cntnrMap" style="display:none"><br/></div>  <!--div> Type of Selecter: <select id="selectorType"> <option value="css selector">CSS Selector</option> <option value="XPath">XPath</option> <option value="RegExp">RegExp</option> </select><br/></div-->Selector: <!--span class="selector"></span--> <input type="text" id="selectorVal"/> <!--br/> Attribute: <select id="attributeTxt"></select><br/> Result: <div id="resultOutput">Display Text</div--><br/> Action Type:   <select id="actionType">  <option value="select">Select Action Type</option>  <option value="click">Click</option>  <option value="scroll">Scroll</option> <option value="pagination">pagination</option> </select>  </br>Element: <input type="text" id="actionElem" class="actionElement"/><br/>  <div id="functionWraper" style="display:none;outline: none;">  Function:   <select class="fnDropdown" id="functionType">  <option value="0">Select a function</option>  <option value="1">substring</option>  <option value="2">escape_character</option>  <option value="3">split</option>  <option value="4">current_timestamp</option>  <option value="5">timeZone_to_string</option>  </select>  </div>  <div id="functionBlock" style="position: absolute;bottom: 0;left: 0;padding: 10px;width: 100%;text-align: right;box-sizing: border-box;">  <hr/>  <button class="ok" id="ok">Ok</button> <button class="cancel" id="cancel">Cancel</button>  </div>  </div>  </div>  <div id="step-2-c" class="content" style="display: none;max-height: 560px;padding-top:20px;">  <h2 class="StepTitle"></h2>  <div id="userModalPopup1">  <div class="modal-body" style="position:relative; overflow: scroll;overflow-x: hidden;height: 530px;"></div>  </div>  </div>  <div id="step-3-c" class="content" style="display: block;height:530px;padding-top:20px;">  <h2 class="StepTitle"></h2>  <iframe id="roviTiVoApp" style="width: 100%; height: 530px; border: 0;" src="' + src + '"></iframe>  </div> 	 <div id="step-4-c" class="content" style="display: none;height:530px;padding-top:20px;"> 			 <!--select id="loginActionType">  <option value="select">Select Action Type</option>  <option value="click">Click</option>  </select-->                                            <div class="loginActionElement">Username: <input type="text" id="loginActionElemU"/></div>  <div class="loginActionElement"> Password: <input type="text" id="loginActionElemP" /></div>  <div class="loginActionElement"> Login Buttn: <input type="text" id="loginActionBtn" />  </div> <div id="functionBlock" style="position: absolute; bottom: 0px; left: 0px; padding: 10px; width: 100%; text-align: right; box-sizing: border-box; outline: none;">  <hr style="outline: none;"> <button class="loginOk" id="loginTrackBtn">Track Login</button>  <button class="loginOk" id="loginOk">Track Login Details</button> <!--button class="cancel" id="cancel">Cancel</button-->  </div>	</div>  </div> </div>';

var appStyle = document.createElement('link');
appStyle.setAttribute('rel', 'stylesheet');
appStyle.setAttribute('type', 'text/css');
appStyle.setAttribute('media', 'screen');
appStyle.setAttribute('href', chrome.runtime.getURL('/src/resources/css/app-style.css'));

var messenger = document.createElement('script');
messenger.type = 'text/javascript';
messenger.src = "chrome-extension://" + chrome.runtime.id + '/src/vendors/messenger/messenger.min..js';


var messengerTheme = document.createElement('script');
messengerTheme.type = 'text/javascript';
messengerTheme.src = "chrome-extension://" + chrome.runtime.id + '/src/vendors/messenger/messenger-theme-flat.js';


var bootstrapJs = document.createElement('script');
bootstrapJs.type = 'text/javascript';
bootstrapJs.src = "chrome-extension://" + chrome.runtime.id + '/src/vendors/bootstrap/bootstrap.js';

var bootstrapCss = document.createElement('link');
bootstrapCss.setAttribute('rel', 'stylesheet');
bootstrapCss.setAttribute('type', 'text/css');
bootstrapCss.setAttribute('media', 'screen');
bootstrapCss.setAttribute('href', chrome.runtime.getURL('/src/vendors/bootstrap/bootstrap.css'));

var hlJs = document.createElement('script');
hlJs.type = 'text/javascript';
hlJs.src = "chrome-extension://" + chrome.runtime.id + '/src/vendors/highlight.js';


var messengerCss = document.createElement('link');
messengerCss.setAttribute('rel', 'stylesheet');
messengerCss.setAttribute('type', 'text/css');
messengerCss.setAttribute('media', 'screen');
messengerCss.setAttribute('href', chrome.runtime.getURL('/src/vendors/messengers/messenger.css'));

var messengerThemeCss = document.createElement('link');
messengerThemeCss.setAttribute('rel', 'stylesheet');
messengerThemeCss.setAttribute('type', 'text/css');
messengerThemeCss.setAttribute('media', 'screen');
messengerThemeCss.setAttribute('href', chrome.runtime.getURL('/src/vendors/messenger/messenger-theme-flat.css'));

var messengerSpinnerCss = document.createElement('link');
messengerSpinnerCss.setAttribute('rel', 'stylesheet');
messengerSpinnerCss.setAttribute('type', 'text/css');
messengerSpinnerCss.setAttribute('media', 'screen');
messengerSpinnerCss.setAttribute('href', chrome.runtime.getURL('/src/vendors/messenger/messenger-spinner.css'));

//validate Modal //
var modal = document.createElement('div');
modal.setAttribute("id", "userModalPopup");
modal.setAttribute("tabindex", "-1");
modal.setAttribute("class", "modal");
modal.innerHTML = '<div class="modal-content"><div class="modal-header"><span class="close" id="btnCloseTop">&times;</span><h5 id="myModalLabel">Scrape Result</h5></div><div class="modal-body"></div><div class="modal-footer"><!--button type="button" class="btn btn-default" >Save</button--><button type="button" id="btnClose" class="btn btn-default" >Close</button></div></div>';

var highlighterDiv = document.createElement('div');
//highlighterDiv.class="highlighter";
highlighterDiv.setAttribute("class", "highlighter");
highlighterDiv.innerHTML = '<div id="xpath"></div><div id="result"></div>';

var labelsContainer = document.createElement('div');
labelsContainer.setAttribute("style", "z-index:9999999");
labelsContainer.setAttribute("id", "labelsContainer");

var jqueryRef = document.createElement('script');
jqueryRef.type = 'text/javascript';
jqueryRef.src = "chrome-extension://" + chrome.runtime.id + '/src/vendors/jquery/jquery-3.1.1.js';

var uiHandler = document.createElement('script');
uiHandler.type = 'text/javascript';
uiHandler.src = "chrome-extension://" + chrome.runtime.id + '/src/chromeExtnResources/uiHandler.js';

//console.log(document.URL + "   " + window.document.body + "    " + document.head + "    " + window); // This is working

var url = document.URL;
var action = (url.indexOf("action=roviWebScraperActive") > -1) ? "roviWebScraperActive" : "null";

if (document.readyState == "complete") {
    setTimeout(function() {
        if (url.split("action=")[0].indexOf("#/visualCrawler") > -1) {
            addVcForm();
        }
    }, 500);

    setInterval(function() {
        //if(url.split("action=")[0].indexOf("#/dashboard") > -1){
        try {
            document.getElementById('extn').style.display = "block";
            document.getElementById('noExtn').style.display = "none";
        } catch (e) {}
    }, 500);

    //chrome.storage.local.set({"flagViewCMData": "false"}, function() {
        //console.log("Chrome storage  : false");
    //});

    chrome.storage.local.get("rootObjectFromLS", function(result) {
        if (result != null) {
            //console.log("Login details captured" + result.rootObjectFromLS.credential.userName.content);
            if (result.rootObjectFromLS != null) {
                loadExtn(result.rootObjectFromLS);
            }
        }


    });

}



// url on load
var currentPage = window.location.href;
var intervalVCF = setInterval(function() {
    if (currentPage !== window.location.href) {
        // page has changed, set new page as 'current'
        currentPage = window.location.href;
        //console.log(currentPage);
        if (window.location.hash == "#/visualCrawler") {
            addVcForm();
            clearInterval(intervalVCF);
        }

        try {
            document.getElementById('extn').style.display = "block";
            document.getElementById('noExtn').style.display = "none";
        } catch (e) {}

    }
}, 500);

// Visual append crawler form
var vcFormSrc = chrome.extension.getURL("/src/views/vcForm.html");

function addVcForm() {
    if (document.getElementById('vcFormDiv') == null) { // satya
        //  var vcFormDiv = document.getElementById('vcFormDiv');
        //  document.getElementById('vcStartForm').removeChild(vcFormDiv);
        // }
        var vcFormContainer = document.createElement('div');
        vcFormContainer.setAttribute("id", "vcFormDiv");
        vcFormContainer.innerHTML = '<iframe id="vcForm" style="width: 100%;    height: 500px;    border: 0;" src="' + vcFormSrc + '"></iframe>';
        setTimeout(function() {
            document.getElementById('vcStartForm').appendChild(vcFormContainer);
            //iframe.contentDocument.write(getFrameHtml('html/iframe-content-page.html'));
        }, 100);
    }
    // chrome.storage.local.set({"credentailsconfigobj": viewCMDataObj}, function(){
    // //  A data saved callback omg so fancy
    // console.log(viewCMDataObj);
    // });

    chrome.storage.local.set({"flagViewCMData": "false"}, function() {
      if(chrome.runtime.lastError){return;}
    });
}


loadExtn();

function loadExtn(jsonWithLogin = null) {
    if (action == "roviWebScraperActive" || (jsonWithLogin != null && jsonWithLogin.credential.userName.content != "")) {


            //iframeContainer.style.cssText += 'display:block;';

            //document.body.appendChild(iframe);
            //document.head.appendChild(hlCss);
            document.head.appendChild(appStyle);
            document.head.appendChild(messengerCss);
            document.head.appendChild(messengerThemeCss);
            document.head.appendChild(messengerSpinnerCss);
            //document.head.appendChild(bootstrapCss);
            document.head.appendChild(jqueryRef); // check if page has jquery, if no add it
            document.body.appendChild(messenger);

            var checkDocumentLoad = setInterval(function() {
                if (document.readyState == "complete") {

                    document.body.appendChild(iframeContainer);

                    //iframe.contentDocument.write(getFrameHtml('html/iframe-content-page.html'));
                    //http://stackoverflow.com/questions/11325415/access-iframe-content-from-a-chromes-extension-content-script



                    document.body.appendChild(labelsContainer);
                    //document.body.appendChild(cntnr);
                    document.body.appendChild(modal);


                    document.body.appendChild(messengerTheme);
                    //document.body.appendChild(bootstrapJs);
                    //document.body.appendChild(hlJs);
                    document.body.appendChild(uiHandler);

                    clearInterval(checkDocumentLoad);
                }
            }, 1000);

        } else {
            //iframeContainer.style.cssText += 'display:none;';
        }
    }



    //getting crawler management page view  data
    var sintr = setInterval(function() {
        //console.log('document.getElementById("view_0")' + document.getElementById("view_0").getAttribute('data-json'));
        var viewCMbutton = document.querySelectorAll('*[id^="view_"]')

        if (viewCMbutton.length != 0) {
            //var viewCMbutton = document.querySelectorAll('*[id^="view_"]');
            //console.log("viewCMbutton" + viewCMbutton);

            for (var i = 0; i < viewCMbutton.length; i++) {
                viewCMbutton[i].addEventListener('click', function(event) {

                    var abc = unescape(this.getAttribute('data-json'));

                    chrome.storage.local.set({ "viewCMData": abc }, function() {
                      console.log("ls storage set");
                    });

                    chrome.storage.local.get("viewCMData", function(result) {
                        if (result.viewCMData != "null") viewCMData = result.viewCMData;
                    });

                    chrome.storage.local.set({"flagViewCMData": "true"}, function() {});

                    viewCMDataObj = JSON.parse(unescape(this.getAttribute('data-json')));

                    var viewVisitUrl = viewCMDataObj.config.matches[0].actualUrl;

                    window.parent.location.replace(viewVisitUrl + "?action=roviWebScraperActive");
                });
            }
        }
    }, 500);
