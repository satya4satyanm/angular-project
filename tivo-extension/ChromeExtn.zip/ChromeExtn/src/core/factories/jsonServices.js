function jsonService() {

    var jsonService = {};
    var rootObject = {
        "validate": "",
        "credential": {
            "loginUrl": "",
            "password": {
                "content": "",
                "value": "",
                "type": "css selector"
            },
            "userName": {
                "content": "",
                "value": "",
                "type": "css selector"
            },
            "preActions": [{
                "url": "",
                "action": "click",
                "type": "css selector",
                "value": ""
            }],
            "postActions": [{
                "url": "",
                "action": "click",
                "type": "css selector",
                "value": ""
            }]
        },
        "config": {
            "siteId": "",
            "definitionId": "",
            "definitionName": "",
            "createdBy": "",
            "isApproved": "",
            "modifiedBy": "",
            "modifiedDate": "",
            "createdDate": "",
            "respectRobotText": false,
            "proxyIP": "",
            "visit": "",
            "trainingUrl": "",
            "matches": []
        },
        "trainingFlow": []
    };


    var matchesJson = {
        "urlPattern": "",
        "actualUrl": "",
        "paginationValue": "",
        "type": "css selector",
        "action": "",
        "links": [],
        "fields": []
    };

    var linksJson = {
        "attribute": "",
        "value": "",
        "type": "css selector",
        "id": "",
        "actions": [] // feed actionJson here
    };

    var actionJson = {
        "action": "",
        "type": "",
        "value": ""
    }

    var fieldsJson = {
        "assetType": "",
        "attribute": "",
        "name": "",
        "type": "",
        "id": "",
        "value": "",
        "actions": [],
        "function": {}, // replace the object value with functionObjJson
        "multiple": "", // if this is true, fields array below must be created with fieldsJson
        "fields": []
    };

    var functionObjJson = {
        "name": "",
        "multiOut": "",
        "parameters": {
            "string": "",
            "operator": ""
        },
        "fields": [] // functionFieldJson are fed here
    }


    jsonService.getBase = function() {
        return baseJson;
    }

    jsonService.getMatchesJson = function() {
        return matchesJson;
    }

    jsonService.getRootObject = function() {
        return rootObject;
    }

    jsonService.getLinksJson = function() {
        return linksJson;
    }

    return jsonService;
}
