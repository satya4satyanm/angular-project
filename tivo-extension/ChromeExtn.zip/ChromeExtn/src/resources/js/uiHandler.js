var mode = "dev";
if (mode == "prod") {
    $("#devMode").hide();
}
var domainUrl = "http://172.26.119.81:8000";
var assetTypeObject = [];
var actionObject = {
    "action": "",
    "type": "css selector",
    "value": ""
}
console.log("hegrwr");


var pageObj = {};


var subsessionObj = {};
var signinObject = {
    "preActions": [],
    "loginUrl": "",
    "password": {
        "content": "",
        "value": "",
        "type": "css selector"
    },
    "userName": {
        "content": "",
        "value": "",
        "type": "css selector"
    },
    "postActions": []
}

var linkObj = {};
var fieldObj = {};

var editClicked = false;
$.fn.hasAttr = function(name) {
    return this.attr(name) !== undefined;
};

function noscript(strCode) {
    var html = $(strCode.bold());
    html.find('script').remove();
    return html.html();
}

//setTimeout(function() {
// Messenger.options = {
//     extraClasses: 'messenger-fixed messenger-on-bottom messenger-on-right',
//     theme: 'flat'
// }
//}, 1000);

var stateManager = {};

var iframe = $('#roviTiVoApp').find("iframe")[0];
if (!iframe) {
    iframe = $('#roviTiVoApp')[0];
};
// $(window).bind('beforeunload', function(event){
// return "Data will be lost if you leave the page, are you sure?";

// });
//console.log("labelIndex"+labelIndex)

var boundIframeListener = function(e) {
    // if (e.data[0] == "selectAssetID") {
    // FormatHTML();
    // }


    if (e.data[0] == "stateManager") {
        Messenger.options = {
                extraClasses: 'messenger-fixed messenger-on-bottom messenger-on-right',
                theme: 'flat'
            }
            //Messenger().post("Got the stateManager object..!");
        stateManager = e.data[1];

        pageObj = stateManager.pages;
        pageObj.push({
            "actualUrl": "",
            "mappingPaused": false,
            "assets": []
        });

        throwMessage();
    }

    if (e.data[0] == "saveSuccess") {
        localStorage.clear();
        Messenger().post("Definition saved successfully..!");
    }

    if (e.data[0] == "saveError") {
        Messenger().post({
            message: 'Definition save error..!',
            type: 'error'
        });
    }


    if (e.data[0] == "goBack") {
        localStorage.clear();

        // show msngr
        var roviMsg = Messenger().post({
            message: 'Data mapped till now will be lost. Would you like to proceed?',
            type: 'info',
            hideAfter: 1200,
            actions: {
                ok: {
                    label: 'Ok',
                    action: function() {
                        iframe.contentWindow.postMessage([
                            'goBackResponse'
                        ], '*');
                    }
                },
                cancel: {
                    label: 'Cancel',
                    action: function() {
                        // do nothing, just close the roviMsg
                        return roviMsg.cancel();
                    }
                }
            }
        });
    }


    if (e.data[0] == "mouseOver") {
        $("#span" + e.data[1]).addClass("class-highlighter");
    }
    if (e.data[0] == "mouseOut") {
        $("#span" + e.data[1]).removeClass("class-highlighter");
    }

    //console.log("In main window roviMsg from iframe :  " + e.data[0]); //window.location.href
    if (e.data[0] == "start_selection") {
        // some times links contain span element
        // if the element is a span or img with no class or id
        // then check the immediate parent for the selector and append this element on selection criteria

        // $("*").click(function(e) {
        // //$(".highlighter").css("display","none");

        // $(".class-highlighter").removeClass( "class-highlighter" );

        // setTimeout(function(){
        // hoverByClass(e.target.className.split(" ")[0],"class-highlighter"); // diplay all similar items
        // }, 200);



        // // console.log("e.target  "+e.target.tagName); // check if its IMG / SPAN
        // //$(e.target).css("border", "none");
        // var xPath = getPathTo(e.target); //
        // $('#roviTiVoApp')[0].contentWindow.postMessage([
        // 'New Field', xPath
        // ], '*');


        // //hoverByClass(e.target.className.split(" ")[0],"1px solid red");
        // //$(this).css("color", "#ff3300");
        // hoverByClass(e.target.className.split(" ")[0],"3px solid red");
        // //$(e.target.className.split(" ")[0]).css("color","5px solid green")
        // console.log(e.target.className.split(" ")[0]);


        // return false;
        // });



    }


    //{"fields":{"Cast":"Alyssa Diaz"},"link":"http://www.cbs.com/shows/zoo/","id":null}
    if (e.data[0] == "editLink") {
        //$("#functionWraper").hide();
        //$("#div_Scheme").hide();
        //$("#div_Scheme1").hide();
        $('#linksOrFieldsDropdown').val('links');
        $("#selectorVal").val(e.data[1].value)
    }
    if (e.data[0] == "editField") {
        //$("#functionWraper").show();
        //$("#div_Scheme").show();
        //$("#div_Scheme1").show();
        $('#linksOrFieldsDropdown').val('fields');
        $("#assetType").val(e.data[1].assetType);
        $("#assetType").trigger("change");
        $("#assetSubType").val(e.data[1].name);
        $("#selectorVal").val(e.data[1].value)
    }


    if (e.data[0] == "createLabels") {
        createlabels(e.data[1], e.data[2]);
    }

    if (e.data[0] == "clearValidateResult") {
        $(".modal-body").empty();
        $(".modal-body").text("Waiting for validation result..!");
    }
    if (e.data[0] == "validate") {
        $(".modal-body").empty();
        var json = e.data[1];
        validateModal.style.display = "block";

        var kk = 0;
        var array = [];
        for (var k in json) //keys.push(k);
        {
            array.push(k);
            if (json[k].links != null) {

                if (json[k].links.length > 0) {
                    $(".modal-body").append("<h5 class='validateHeader1'>" + k + "</h5>");
                }

                $(".modal-body").append("<th class='validateHeader2'>" + "Links" + "</th>");

                $(".modal-body").append('<table id="example_' + kk + '" class="display rowclass" cellspacing="0" width="100%"><thead><tr></tr></thead></table></br>');
                $('#example_' + kk)
                    .removeClass('display')
                    .addClass('table table-striped');
                var tr;
                tr = $('<tr/>');

                $('#example_' + kk).append(tr);

                $('#example_' + kk + ' tr').addClass('rowborder');
                for (i = 0; i < json[k].links.length; ++i) {
                    tr = $('<tr/>');
                    var id = $(this).attr("id");
                    tr.append('<td><span class="vlinks" style="font-size:15px">' + json[k].links[i] + '</span></td>');
                    $('#example_' + kk)
                        .removeClass('display')
                        .addClass('table table-striped');
                    $('#example_' + kk).append(tr);
                }

            }
            var splitedUrl;
            $(".vlinks").bind("mouseover", function(e) {
                var mouseoverUrl = $(e.target).text()
                var windowUrl = (window.location.href).split('?')[0]
                var array1 = mouseoverUrl.split('/');
                var array2 = windowUrl.split('/');
                array1 = $(array1).not(array2).get();
                splitedUrl = "/" + array1.join('/');
                $("[href*='" + splitedUrl + "']").css("outline", "3px solid #cdd827");
                //console.log("window url" + windowUrl);
            });
            $(".vlinks").bind("mouseout", function(e) {
                $("[href*='" + splitedUrl + "']").css("outline", "none");
            });

            if (json[k].fields != null && json[k].fields[0] != null) {
                if (json[k].fields.length > 0) {
                    $(".modal-body").append("<h5 class='validateHeader1'>" + k + "</h5>");
                }
                $(".modal-body").append("<th class='validateHeader2'>" + "Fields" + "</th>");
                $(".modal-body").append('<table id="example1_' + kk + '" class="display rowclass" cellspacing="0" width="100%"><thead><tr></tr></thead></table></br>');
                $('#example1_' + kk)
                    .removeClass('display')
                    .addClass('table table-striped');
                var tr1;
                tr1 = $('<tr/>');
                $('#example1_' + kk).append(tr1);
                $('#example1_' + kk + ' tr').addClass('rowborder');
                for (var l in json[k].fields[0]) {

                    tr1.append("<th>" + l + "</th>");
                    $('#example1_' + kk).append(tr1);
                }
                tr1 = $('<tr/>');
                for (var l in json[k].fields[0]) {
                    tr1.append('<td><span class="vfields" style="font-size:15px">' + json[k].fields[0][l] + "</span></td>");

                    $('#example1_' + kk)
                        .removeClass('display')
                        .addClass('table table-striped');
                    $('#example1_' + kk).append(tr1);

                }

            }
            var mouseoverText;
            var a = [];
            $(".vfields").bind("mouseover", function(e) {
                mouseoverText = $(e.target).text()
                $('*').each(function() {
                    if ($(this).text() == mouseoverText) {
                        a.push($(this));
                    }
                });

                for (i = 0; i < a.length; i++) {
                    if (a[i].parents('#userModalPopup1').length < 1) {
                        $(a[i]).css("outline", "3px solid #cdd827");
                    }
                }
            }).bind("mouseout", function(e) {
                for (i = 0; i < a.length; i++) {
                    $((a[i])).css("outline", "none");
                }
            });


            kk++;
        }
    }


}
window.addEventListener('message', boundIframeListener, true);


rightClickedElement = "";

function pageLevelMouseover() {
    $("*").mouseover(function(e) {
        if (($(e.target).parents('.window').length > 0) || ($(e.target).parents('#cntnr').length > 0) || ($(e.target).parents('.messenger-message').length > 0) || ($(e.target) == $('.messenger-message') > 0) || ($(e.target).parents('.label').length > 0) || ($(e.target).attr('id') == "cntnr") || ($(e.target).attr('class') == "label") || ($(e.target).attr('id') == "collapse-right") || ($(e.target).parents('#l1').length > 0) || $(e.target).parents('.messenger').length > 0 || $(e.target).attr('class') == "messenger" || ($(e.target).parents('#collapse-right').length > 0)) {} else {
            $(e.target).addClass("class-highlighter-red");
        }
    });

    $("*").mouseout(function(e) {
        var t = e.target;
        $(e.target).removeClass("class-highlighter-red");
    });
}




//#################  sub session flow start
currentSubsession = 'listing';
roviCurrentQ = 0;

$("#start").click(function() {
    //$("*").css("-webkit-filter", "grayscale(100%)");
    //$("*").css({ "-moz-filter": "grayscale(100%)", "-webkit-filter": "grayscale(100%)", "filter": "gray", "filter": "grayscale(100%)"});
    $(this).hide();
    roviCurrentQ++;
    throwMessage();
    $("#div_Scheme").show();
});


function throwMessage(roviMsgtxt = "", nestedroviMsg = false) {
    // nested messages are informative
    // if(currentSubsession == '') {
    //   Messenger().post(stateManager.allQs[roviCurrentQ].q);
    // }
    //var callback = null;
    if (nestedroviMsg == true) {
        Messenger().post({
            message: roviMsgtxt,
            hideAfter: 15
        });
        //return true;
    } else if (stateManager.allQs[roviCurrentQ].type == "Informative") {
        Messenger().post({
            message: stateManager.allQs[roviCurrentQ].q,
            hideAfter: 15
        });

        if (stateManager.allQs[roviCurrentQ].callback != undefined) {
            var callback = stateManager.allQs[roviCurrentQ].callback;
            window[callback]();
        }

        //return true;
    } else if (stateManager.allQs[roviCurrentQ].type == "YesOrNo") {

        var msg = stateManager.allQs[roviCurrentQ].q;
        var ycb = stateManager.allQs[roviCurrentQ].yesCallback;
        var ncb = stateManager.allQs[roviCurrentQ].noCallback;


        var roviMsgR;
        roviMsgR = Messenger().post({
            message: msg,
            hideAfter: 1200,
            actions: {
                Yes: {
                    action: function() {
                        window[ycb]();
                        return roviMsgR.cancel();
                    }
                },
                No: {
                    action: function() {
                        window[ncb]();
                        return roviMsgR.cancel();
                    }
                }
            }
        });
    }
}



var mandatoryFieldMapingState = false;
var assetIdMappingInProgress = false;
var assetTitleMappingInProgress = false;

function createMandatoryAttributeSubSession() {
    $("#subSessionContainer").show();
    $("#subSessionControls").show();
    $("#subSessionDone").show();

    mandatoryFieldMapingState = true;

    if (roviCurrentQ == 2) {
        assetIdMappingInProgress = true;
        var select = $('#assetSubType'),
        options = select.find('option');
        var visibleItems = options.filter('[value*="' + 'asset Id'  + '"]').show();
        if(visibleItems.length > 0)
        {
          select.val(visibleItems.eq(0).val());
        }


    } else if (roviCurrentQ == 3) {
        assetIdMappingInProgress = false;
        assetTitleMappingInProgress = true;

    }

    pageLevelMouseover();
    $(document).bind("contextmenu", rightClick);

    pageObj[0].assets[currentAssetIndex].subSessions.mandatoryAttributes = {
        "active": true,
        "noOfAttributesMapped": 1
    }

    //disableLinks();
    $("#subSessionDone").off('click').on("click", function() {
        //enableLinks();
        roviCurrentQ++;
        throwMessage();
        $("#subSessionDone").off("click");

        if (stateManager.allQs[roviCurrentQ].callback != undefined) {
            var callback = stateManager.allQs[roviCurrentQ].callback;
            window[callback]();
        }
    });


}


function createAttributeSubSession() {
    mandatoryFieldMapingState = false;
    assetTitleMappingInProgress = false;
    $("#subSessionContainer").show();
    $("#subSessionControls").show();
    $("#subSessionDone").show();


    //  $("#subSessionDone").off("click");

    pageObj[0].assets[currentAssetIndex].subSessions.allAttributes = {
        "active": true,
        "noOfAttributesMapped": 1
    }

    if (stateManager.allQs[roviCurrentQ].yesMessage != "") {
        throwMessage(stateManager.allQs[roviCurrentQ].yesMessage, true);
    }

    //disableLinks();
    $("#subSessionDone").off('click').on("click", function() {
        //enableLinks();
        roviCurrentQ++;
        throwMessage();
        $("#subSessionDone").off("click");
    });

    if (roviCurrentQ == 8) {
        $("#subSessionDone").text("Done");
    } else {
        $("#subSessionDone").text("Done");
    }

}


function createDetailSubSession(){
     roviCurrentQ=10;
     throwMessage();
     $("#subSessionDone").bind("click",function(){
       roviCurrentQ++;
       throwMessage();
       $("#subSessionDone").unbind("click");
     });
   }

var paginationInActive = false;
var scrollPaginationInActive = false;


function createPaginationSubSession() {
    paginationInActive = true;
    $("#subSessionContainer").show();
    $("#subSessionControls").show();
    $("#subSessionDone").show();

    pageObj[0].assets[currentAssetIndex].subSessions.pagination = {
        "active": true,
        "noOfAttributesMapped": 1
    }

    $("#subSessionContainer .subSessionLabels.active").removeClass("active");

    if ($("#subsessionbtn").text().indexOf("Pagination") > -1) {} else {
        var btn = $('<button/>', {
            text: "Pagination",
            class: 'subSessionLabels active',
            click: function() {

            }
        });
        $("#subsessionbtn").append(btn);
        $("#subSessionContent").empty();
    }


    if (stateManager.allQs[roviCurrentQ].paginationType == "click") {
        //disableLinks();

        throwMessage(stateManager.allQs[roviCurrentQ].yesMessage, true);

        $("#subSessionDone").bind("click", function() {
            paginationInActive = false;
            //enableLinks();
            roviCurrentQ += 2;
            throwMessage();
            $("#subSessionDone").unbind("click");

            if (stateManager.allQs[roviCurrentQ].callback != undefined) {
                var callback = stateManager.allQs[roviCurrentQ].callback;
                window[callback]();
            }
        });
    } else if (stateManager.allQs[roviCurrentQ].paginationType == "scroll") {
        scrollPaginationInActive = true;
        $("#subSessionDone").bind("click", function() {
            scrollPaginationInActive = false;
            roviCurrentQ++;
            throwMessage();
            $("#subSessionDone").unbind("click");

            if (stateManager.allQs[roviCurrentQ].callback != undefined) {
                var callback = stateManager.allQs[roviCurrentQ].callback;
                window[callback]();
            }
        });
    }




}




function next() {
    roviCurrentQ++;
    throwMessage();
    if (stateManager.allQs[roviCurrentQ].callback != undefined) {
        var callback = stateManager.allQs[roviCurrentQ].callback;
        window[callback]();
    }
}
function nextEnd() {
    Messenger().post("Please validate or save the definition.");
    changeTab(3);
}


function enableLinks() {
    $("a").each(function() {
        $(this).attr("href", $(this).attr("rel"));
        $(this).removeAttr("rel");
    });
    return true;
}



function disableLinks() {
    $("a").each(function() {
        $(this).attr("rel", $(this).attr("href"));
        $(this).attr("href", "javascript:;");
    });
    return true;
}



function createNewAsset() {
        $("#div_Scheme").show();
        roviCurrentQ = 1;
        throwMessage();
    }
    //###################  sub session flow end




iframe.contentWindow.postMessage([
    'visitUrl', window.location.href
], '*');




$(document).mouseup(function(e) {
    var selection = window.getSelection();
    var text = selection.toString();
    var len = text.length;
    if ($('pre').find(e.target).length > 0 && len > 1) {
        getSelectionText(e);
    } else {
        $("#qs-popup").hide();
    }
});


var htmlContent = noscript($('html').html());

function getSelectionText(e) {

    //console.log(e.target);

    var selection = window.getSelection();
    var text = selection.toString();
    var len = text.length;
    var range = selection.getRangeAt(0).cloneRange();
    var rect = range.getClientRects()[0];
    var left = rect.left;
    var top = rect.top;
    var right = rect.right;
    var mid = (left + right) / 2
    var scroll = $(".modal-body").scrollTop();


    // position the popup
    var showPopup = {
        'top': top + scroll - 80,
        'left': mid - 170
    };


    var id = 'qs-popup';
    var id1 = 'button-popup';
    if ($('#' + id).length) {} else {
        $(".modal-body").append('<div id="' + id + '"><div id="buttonRaper" style="display:inline-flex;"><input id="finalizedObjId" class="' + id1 + '"type="button" style="margin:3px;" value="Ok"/><input id="finalizedObjIdCncl" class="' + id1 + '" type="button" style="margin:3px;" value="Clear"/></div></div>');
    }
    $('#' + id).show();

    // style popup menu
    $('#' + id).css({
        'background': '#262626',
        'font-size': '24px',
        'border-radius': '4px',
        'box-sizing': 'border-box',
        'position': 'absolute',
        'top': showPopup.top,
        'left': showPopup.left
    });
    $('.' + id1).css({
        'background': '#3498db',
        '-webkit-border-radius': '8',
        '-moz-border-radius': '8',
        'border-radius': '8px',
        'border': '0',
        'font-family': 'Arial',
        'color': '#ffffff',
        'font-size': '15px',
        'padding': '5px',
        'text-decoration': 'none'
    });


    $('#finalizedObjId').bind("click", function() {
        iframe.contentWindow.postMessage([
            'source', text
        ], '*');
        $('#' + id).hide();
        $('#validateModal').modal('hide');
    });
    $('#finalizedObjIdCncl').bind("click", function() {
        $('#' + id).hide();
        selection.empty();

    });

    $(".modal-body pre").unbind('mouseup');

    return text;
}


hoverByClass = function(classname, colorover) {
    //console.log("hoverByClass called");

    var elementSelector = classname.split("/").join(" ");
    var elms = $(elementSelector);
    for (var i = 0; i < elms.length; i++) {
        $(elms[i]).addClass("class-highlighter");
    }

}

var reachedWithFewItems = false;

getPathTo = function(element) { // this should return the unique ID/class/path, if user is not satisfied with the selector he will enter regexp
    //console.log("getPathTo called");
    if (element.id !== '') {
        return '#' + element.id;
    } else if (element.className.split(" ")[0] !== '' && element.className.split(" ")[0] !== 'class-highlighter' && element.className.split(" ")[0] !== 'class-highlighter-red') {
        if (element.parentNode.childNodes.length > 1) {
          var nodeList = Array.prototype.slice.call( element.parentNode.childNodes );
          return '.' + element.className.split(" ")[0] + ":nth-child("+nodeList.indexOf( element )+")";
        } else {
          return '.' + element.className.split(" ")[0]; // use cases can be there for multiple class selector
        }
    } else {
        if (element.parentNode.childNodes.length > 1) {
            var nodeList = Array.prototype.slice.call( element.parentNode.childNodes );

            return getPathTo(element.parentNode) + ' ' + element.tagName+":nth-child("+nodeList.indexOf( element )+")";
        } else {
            return getPathTo(element.parentNode) + ' ' + element.tagName;
        }
    }
}
currentElement = null;
//currentEleSelector = "";
schemaName = "";
var labelIndex = 0;

finalSelector = "";
var hrefAttributes = [];

$("a").each(function() {
    //if($(this).parents().has(".modal-body")) {
    //if($(this).parents().has("#cntnr")) {
    if ($(this).parents('#cntnr').length < 1) {
        //hardcoded for cbs alone
        if ($(this).attr("href") != "javascript:void(0);") {
            $(this).attr("href", $(this).attr("href") + "?action=roviWebScraperActive");
        }
    }
});

function checkElementHasA(elem) {
    if ($(elem)[0].tagName == "A") {
        return true;
    } else {
        if ($(elem)[0].tagName == "BODY") {
            return false;
        } else {
            return checkElementHasA($(elem).parent());
        }
    }
}


function checkElementHasImage(elem) {
    if ($(elem)[0].tagName == "IMG") {
        return true;
    } else {
        return false;
    }
}

function getParentIdClassNameIfFoundMore(elem) {
    var selectedElementPath = "";
    selectedElementPath = getPathTo(currentElement);

    if ($(elem)[0].tagName == "BODY") {
        return "";
    } else {
        elem = $(elem);
        if (elem.find(selectedElementPath).length > 1) {
            var getUPath = getUniquePath($(elem)[0]);
            return getUPath;
        } else {
            return getParentIdClassNameIfFoundMore(elem.parent());
        }
    }

}



function createLabelsStep2(obj, currentMatchIndex, type) {
    if (type == "links") {
        $('#labelsContainer').append('<span class="label" id="span' + obj.labelIndex + '" data-obj=""><span class="txt">' + assetToAdd + "  " + "Detail Url" + '</span><span class="edit">E</span><span class="delete">x</span></span>');

    } else {
        $('#labelsContainer').append('<span class="label" id="span' + obj.labelIndex + '" data-obj=""><span class="txt">' + obj.name + '</span><span class="edit">E</span><span class="delete">x</span></span>');
    }


    $("#span" + obj.labelIndex).css("position", "absolute");
    $("#span" + obj.labelIndex).css("left", $(obj.trainingElement).offset().left);
    $("#span" + obj.labelIndex).css("top", $(obj.trainingElement).offset().top);
    $("#span" + obj.labelIndex + " .delete").attr("data-index", obj.labelIndex);
    $("#span" + obj.labelIndex + " .edit").attr("data-index", obj.labelIndex);
    selectedAssetType = $("#assetType").val();
    selectedAssetSubType = $("#cntnr #assetSubType").val();

    $("#span" + obj.labelIndex + " .delete").attr("data-fieldType", selectedAssetType + "---" + selectedAssetSubType);
    currentMatchIndexInUIHandler = currentMatchIndex;
    $("#span" + obj.labelIndex + " .edit").bind("click", function(e) {
        editIndex = $(e.target).attr("data-index");
        id = $(e.target).parent().attr("id");
        editClicked = true;
        changeTab(1);

        iframe.contentWindow.postMessage([
            'Edit', editIndex, currentMatchIndexInUIHandler
        ], '*');
    })
    $("#span" + obj.labelIndex + " .delete").bind("click", function(e) {

        var confirmFromUser = confirm("Are you sure to delete the mapped item?");
        if (confirmFromUser) {
            var assetType = $(e.target).attr("data-fieldType").split("---");
            $(e.target).parent().remove();
            var len_ = assetTypeObject.length;
            for (var i = 0; i < len_; i++) {
                if ((assetTypeObject[i][0] == assetType[0]) && (assetTypeObject[i][1] == assetType[1])) {
                    assetTypeObject.splice(i, 1);
                    break;
                }
            }
            index = $(e.target).attr("data-index")
            iframe.contentWindow.postMessage([
                'Remove', index, currentMatchIndex
            ], '*');

        }
    });
}



var refreshedit = "";
var currentMatchIndexInUIHandler = null;

function createlabels(data, currentMatchIndex) {
    refreshedit = true;
    if (data.actualUrl == window.location.href.split("?action=")[0]) {
        for (var i = 0; i < data.fields.length; i++) {
            createLabelsStep2(data.fields[i], currentMatchIndex, "fields");
        }
        for (var i = 0; i < data.links.length; i++) {
            createLabelsStep2(data.links[i], currentMatchIndex, "links");
        }

        labelIndex = data.links.length + data.fields.length;
    }
}


var getUniquePath = function(node) {

    var parts = [];

    var generatePath;
    if ($(node).parent().children().length > 1) {
        parts.push(node.tagName + ':nth-child(' + ($(node).index() + 1) + ')');
    } else {
        parts.push(node.tagName);
    }
    $(node).parents().each(function(index, element) {
        if (element.tagName == "BODY") {
            parts.push(element.tagName);
            generatePath = parts.join(' > ', parts.reverse());
            return generatePath;
        } else {
            if ($(element).parent().children().length > 1) {
                parts.push(element.tagName + ':nth-child(' + ($(element).index() + 1) + ')');
            } else {
                parts.push(element.tagName);
            }
        }
    });

    return generatePath;
}

var fullpath;
var multipleSelector = [];


function updateSelectorVal(target) {
  var path = getPathTo(target);
  var parentPath = getParentIdClassNameIfFoundMore(target);

  var _path = parentPath + " " + path;

  if ($.inArray(_path, multipleSelector) == -1 || multipleSelector.length == 0) {
      multipleSelector.push(_path);
  } else {
      // $(_path).removeClass("class-highlighter");
      // $(_path).removeClass("class-highlighter-yellow");
      // $(_path).removeClass("class-highlighter-red");
      //
      // var index = multipleSelector.indexOf(_path);
      // multipleSelector.splice(index, 1);
  }

  if (multipleSelector.length > 1) {
      finalSelector=multipleSelector.join(", ");
  } else {
      finalSelector=multipleSelector[0];
  }
}

var elementTreeHasA = false;
var elementTreeHasImage = false;

function rightClick(e) {
    //if(!mandatoryFieldMapingState) {

    e.preventDefault();
    e.stopPropagation();

    editClicked = false;
    currentElement = e.target;
    fullpath = getUniquePath(currentElement);
    //$(document).unbind("contextmenu", rightClick);
    //highlightResults(e);   messenger
    if ($(e.target).parents('.window').length > 0) {} else
    if ($(e.target).parents('#cntnr').length > 0) {} else
    if ($(e.target).parents('.label').length > 0) {} else
    if ($(e.target).attr('id') == "cntnr") {} else
    if ($(e.target).attr('class') == "label") {} else
    if ($(e.target).attr('id') == "collapse-right") {} else
    if ($(e.target).parents('#l1').length > 0) {} else
    if ($(e.target).parents('.messenger').length > 0) {} else
    if ($(e.target).attr('class') == "messenger") {} else
    if ($(e.target).parents('#collapse-right').length > 0) {} else {
        // if(loginFlowComplete) {
        //   changeTab(1);
        // }
        $("#devMode").show();
        if (paginationInActive) {
            fullpath = getUniquePath(currentElement);
            $("#selectorVal").val(fullpath);
            $("#div_Scheme1").hide();
            $("#ok").text("Track Pagination");
            return;
        }

        if (assetIdMappingInProgress || assetTitleMappingInProgress) {
          finalSelector = "";
          finalSelector = getUniquePath(e.target);
        } else {



          updateSelectorVal(e.target);
          //return multipleSelector;

        }



        //var elms = $(parentPath + " " + path);
        // for (var i = 0; i < elms.length; i++) {
        //     $(elms[i]).addClass("class-highlighter");
        // }
        //$(e.target).addClass("class-highlighter-red");



        content = $(e.target).text();


        elementTreeHasImage = checkElementHasImage(currentElement);
        if (elementTreeHasImage != true) {
            elementTreeHasA = checkElementHasA(currentElement);
        }

        $("#cntnrMap").empty();
        $('#attributeTxt').empty();
        //$('#selectorVal').val("");
        $("#resultOutput").empty();
        $("#actionElem").val("");

        var checkAssetType = $('#assetType').val();
        if (checkAssetType !== 'select') {
            $("#assetSubType").focus();
        }

        checkElementType();

        highlightElements(typeOfElement);

        $("#selectorVal").val(finalSelector.trim());
    }
};
//$(document).bind("contextmenu", rightClick);

var urlPatterns = (localStorage.getItem("urlPatterns") != null) ? JSON.parse(localStorage.getItem("urlPatterns")).p : [];

// function createAttrDropdown() {
// var stringDisplay = "";
// var urlValues = [];
// var checkpattern=[];
// $("#attributeTxt option").remove();

// if (finalSelector.trim() != "") {
// var sel = $(currentElement).closest(finalSelector)[0].attributes;
// $("#attributeTxt").append("<option value=''>Select</option>");
// if ($("#linksOrFieldsDropdown").val() == "fields") {
// $("#attributeTxt").append("<option value=''>Text</option>");
// }
// for (var i = 0; i < sel.length; i++) {
// $("#attributeTxt").append("<option value='" + sel[i].name + "'>" + sel[i].name + "</option>"); // [0] is not correct, it must be the right clicked element or nearby element
// }

// //$("#attributeTxt").change(function() { highlightElements() });
// }

// }

var typeOfElement = "link"; // "text", "image"
function checkElementType() {
  if (elementTreeHasImage == true) {

     typeOfElement = "image";
     $("#linksOrFieldsDropdown").val("images");
     $("#assetSubType").val("image");

     $("#functionWraper").hide();
     $(".splitWraper").hide();
     $("#div_Scheme").hide();
     if (!paginationInActive) {
         $("#div_Scheme1").show();
     }
 }
   else if (elementTreeHasA == true) {
        typeOfElement = "link";
        $("#linksOrFieldsDropdown").val("links");
        $("#assetSubType").val("url");

        $("#functionWraper").hide();
        $(".splitWraper").hide();
        $("#div_Scheme").hide();
        if (!paginationInActive) {
            $("#div_Scheme1").show();
        }
    }  else {
      typeOfElement = "text";
      $("#linksOrFieldsDropdown").val("fields");
      $("#functionWraper").show();
      //$("#div_Scheme").show();
      if (!paginationInActive) {
          $("#div_Scheme1").show();
      }
  }
}



function highlightElements(type) {
    stringDisplay = "";
    $("#cntnr #resultOutput").html("");
    //var attributeStr = "";
    var urlValues = [];
    try {
        $(finalSelector.trim()).each(function() {
            $(this).addClass(" class-highlighter");
            if (type == "link") {
                urlValues.push($(this).prop('href'));
            }
        });
        if (urlValues.length > 0) {
            urlPatterns.push(generateUrlPattern(urlValues, 3));
            localStorage.setItem("urlPatterns", JSON.stringify({
                p: urlPatterns
            }));
        }
    } catch (e) {}
}


function generateUrlPattern(urlValues, index, urlPatternString = "") {


    if (typeof urlValues[0] == "string") {
        for (i = 0; i < urlValues.length; i++) {
            urlValues[i] = urlValues[i].split('/');
        }
    }
    var array = [];
    var urlPattern = (urlPatternString != "") ? urlPatternString : urlValues[0][0] + "/" + urlValues[0][1] + "/" + urlValues[0][2] + "/";

    var elementVal = urlValues[0][index]; // shows
    var urlPatternFinalized = false;

    for (i = 1; i < urlValues.length; i++) {
        if (urlValues[i][index] != elementVal) {
            urlPattern += ".*";
            array = urlPattern
                //console.log("urlPattern" + array);
            urlPatternFinalized = true;
            break;
        }
    }

    if (!urlPatternFinalized) {
        urlPattern += elementVal + "/";
        generateUrlPattern(urlValues, index + 1, urlPattern);
    }
    return urlPattern;

}


function getAttrName(str) {
    var firstIndex = str.lastIndexOf("[");
    var lastIndex = str.lastIndexOf("]");
    return str.substring(firstIndex + 1, lastIndex).split("=")[0];
}


//disableAllEventsOnThePage();
function disableAllEventsOnThePage() {
    $("a").click(function(e) {
        e.preventDefault();
    });
    //$(":input").attr('disabled', 'disabled');
}


function fetchHrefAttr(elem) {
    hrefAttributes = [];

    if ($(elem).hasAttr("href")) { // check if element has href and return
        hrefAttributes.push({
            "name": "href",
            "value": $(elem).attr("href")
        });
        return true;
    } else {

        for (var i = 0; i < elem.attributes.length; i++) { // check if element has href similar and return
            if (elem.attributes[i].name.indexOf("href") > -1) {
                hrefAttributes.push({
                    "name": elem.attributes[i].name,
                    "value": elem.attributes[i].value
                });
            }
        }
        if (hrefAttributes.length > 0) {
            return true;
        } else {
            var allChildElements = $(elem).find('*');
            for (var i = 0; i < allChildElements.length; i++) {
                var attrs = allChildElements[i].attributes;

                // check if it has href

                if ($.inArray("href", attrs)) {
                    hrefAttributes.push({
                        "name": "href",
                        "value": $(allChildElements[i]).attr("href")
                    });
                } else {
                    for (var j = 0; j < attrs.length; j++) {
                        if (attrs[j].name.indexOf("href") > -1) {
                            hrefAttributes.push({
                                "name": attrs[j].name,
                                "value": attrs[j].value
                            });
                        }
                    }
                }
            }
            if (hrefAttributes.length > 0) {
                return true;
            } else {
                fetchHrefAttr($(elem).parent()[0]);
            }
        }

    }

}

if (typeof(Storage) !== "undefined" || typeof(Storage) !== null) {
    localStorage.setItem("trainingUrlTracked", "false"); // Verify the use of this var
} else {
    // Sorry! No Web Storage support..
}
var editIndex, id, assetToAdd;



$("#ok").click(function() {




    var assetSubValue = $("#cntnr #assetSubType").val();


    if (assetSubValue !== 'select' || paginationInActive) {

        $("#div_Scheme1").show();
        $("#ok").text("Add Attribute");
        $(".class-highlighter-yellow").removeClass("class-highlighter-yellow");
        assetToAdd = pageObj[0].assets[currentAssetIndex].assetTitle;

    if(paginationInActive){
         $("#subSessionContent").append('<div id="ssLabels_' + labelIndex + '">' + assetToAdd + " "+ "pagination "  +'</div>')
        }
    else{
          if ($("#linksOrFieldsDropdown").val() == "links") {
            if(editClicked== false && assetSubValue != 'asset Id') {
                $("#subSessionContent").append('<div id="ssLabels_' + labelIndex + '">' + assetToAdd + " " + assetSubValue + '</div>')
            }

        } else {
            if(editClicked== false && assetSubValue != 'asset Id') {
                $("#subSessionContent").append('<div id="ssLabels_' + labelIndex + '">' + assetToAdd + " " + assetSubValue + '</div>')
            } else {
                $("#ssLabels_" + editIndex).text(assetSubValue);
            }
        }
      }


      if (editClicked == false) {
          $("DIV[id^='ssLabels_']").bind("mouseover", function(e) {
              var index = $(e.target).attr("id").split("ssLabels_")[1];
              $("#span" + index).addClass("class-highlighter");
          });
          $("DIV[id^='ssLabels_']").bind("mouseout", function(e) {
              var index = $(e.target).attr("id").split("ssLabels_")[1];
              $("#span" + index).removeClass("class-highlighter");
          });
      }

        $("#devMode").hide();
        iframe.contentWindow.postMessage([
            'updatePageObj', pageObj
        ], '*');
        dropdownValue = $("#linksOrFieldsDropdown").val();
        fieldObj = {
            "trainingElement": "",
            "assetType": "",
            "assetTypeId": "",
            "attributeId": "",
            "name": "",
            "attribute": "",
            "type": "",
            "id": "",
            "value": "",
            "labelIndex": labelIndex,
            "actions": [],
            "function": {
                "name": "",
                "multiOut": "",
                "parameters": {
                    "param1": "",
                    "param2": ""
                },
                "fields": []
            }
        };

        linkObj = {
            "trainingElement": "",
            "assetType": "",
            "assetTypeId": "",
            "attributeId": "",
            "name": "",
            "attribute": "href",
            "value": "",
            "type": "css selector",
            "id": "",
            "actions": [],
            "labelIndex": labelIndex
        };



        if (dropdownValue == "fields" || dropdownValue == "images") {

            fieldObj.assetType = $("#assetType").val();
            fieldObj.name = $("#assetSubType").val();
            fieldObj.type = "css selector";
            fieldObj.value = $("#selectorVal").val();

            fieldObj.labelIndex = labelIndex;


            if (assetIdMappingInProgress || assetTitleMappingInProgress) {
                fieldObj.name = "asset Id";
                fieldObj.attribute = "";
            }
            if ($('#assetSubType').val() == "image") {
                fieldObj.attribute = "src";
            } else  if ($('#assetSubType').val() == "url") {
                fieldObj.attribute = "href";
            } else {
                fieldObj.attribute = "";
            }

            if (assetIdMappingInProgress) {
                $("#AssetIdSelectorVal").val($("#selectorVal").val());
            }

            if (assetTitleMappingInProgress) {
                fieldObj.name = "title";
                $("#AssetTitleSelectorVal").val($("#selectorVal").val());
            }

            fieldObj.trainingElement = fullpath;

            /*if ($(finalSelector).length > 1) {
                fieldObj.multiple = "true";
            } else {
                fieldObj.multiple = "false";
            }*/

            //action click start
            actionObject.action = $("#actionType").val();
            actionObject.value = $("#actionElem").val();

            if ($("#linksOrFieldsDropdown").val() == "fields" && $("#actionElem").val() !== "" && $("#actionType").val() == "click") {
                fieldObj.actions.push(actionObject);
            }
            //action click end


            //assetTypePush();

            if ($("#linksOrFieldsDropdown").val() == "fields" && $("#actionType").val() == "scroll") {
                actionObject.action = "Scrolldown";
                fieldObj.actions.push(actionObject);
            }

        } else {


            //name = "";

            linkObj.value = $("#selectorVal").val();
            linkObj.name = $("#assetSubType").val();
            linkObj.trainingElement = fullpath;


            if ($("#linksOrFieldsDropdown").val() == "links" && $("#actionElem").val() !== "" && $("#actionType").val() == "click") {
                linkObj.actions.push(actionObject);
            }
            if ($("#linksOrFieldsDropdown").val() == "links" && $("#actionType").val() == "scroll") {
                actionObject.action = "Scrolldown";
                linkObj.actions.push(actionObject);

            }

            if (assetIdMappingInProgress || assetTitleMappingInProgress) {
                linkObj.name = "asset Id";
                linkObj.attribute = "";
            }

            if ($('#assetSubType').val() == "image") {
                linkObj.attribute = "src";
            } else  if ($('#assetSubType').val() == "url") {
                linkObj.attribute = "href";
            } else {
                linkObj.attribute = "";
            }

            if (assetIdMappingInProgress) {
                $("#AssetIdSelectorVal").val($("#selectorVal").val());
            }

            if (assetTitleMappingInProgress) {
                linkObj.name = "title";
                $("#AssetTitleSelectorVal").val($("#selectorVal").val());
            }

            if (paginationInActive) {
                linkObj.paginate = true;
            } else if (scrollPaginationInActive) {
                // add scroll pagination code here
            }

        }

        if (editClicked == true) {
            assetType = $("#assetType").val();
            value = $("#selectorVal").val();
            if (dropdownValue == "fields") {
                name = $("#cntnr #assetSubType").val();
                var ii = $('#' + id).find(".txt");
                $(ii).text(name);
            } else {
                name = "";
            }
            iframe.contentWindow.postMessage([
                'updateMatch', window.location.href, assetType, name, value, dropdownValue, editIndex, currentMatchIndexInUIHandler
            ], '*');
        } else if ($("#selectorVal").val() != "") {
            if (localStorage.getItem("trainingUrlTracked") === "false") {
                localStorage.setItem("trainingUrlTracked", "true"); // set this to false when that item label is deleted, remove trainingUrl
            }
            iframe.contentWindow.postMessage([
                'addMatch', window.location.href, JSON.parse(localStorage.getItem("urlPatterns"))
            ], '*');
            schemaName = $("#cntnr .schemaName").val();
            //$("#cntnr").hide();
            //$(document).unbind("click");
            //$(currentElement).css("outline", "4px solid #e5e500");
            if ($("#linksOrFieldsDropdown").val() == "links" && $("#cntnr #assetSubType").val()!="asset Id") {
                $('#labelsContainer').append('<span class="label" id="span' + labelIndex + '" data-obj=""><span class="txt">' + assetToAdd + "  " + $("#cntnr #assetSubType").val() + '</span><span class="edit">E</span><span class="delete">x</span></span>');
            } else if ($("#linksOrFieldsDropdown").val() == "fields" && $("#cntnr #assetSubType").val()!="asset Id") {
                $('#labelsContainer').append('<span class="label" id="span' + labelIndex + '" data-obj=""><span class="txt">' + assetToAdd + "  " + $("#cntnr #assetSubType").val() + "  " + '</span><span class="edit">E</span><span class="delete">x</span></span>');
            } else if ($("#linksOrFieldsDropdown").val() == "images" && $("#cntnr #assetSubType").val()!="asset Id") {
                $('#labelsContainer').append('<span class="label" id="span' + labelIndex + '" data-obj=""><span class="txt">' + assetToAdd + "  " + $("#cntnr #assetSubType").val() + "  " + '</span><span class="edit">E</span><span class="delete">x</span></span>');
            }


            $("#span" + labelIndex).css("background-color", "rgba(0, 0, 0, 0.65);");
            $("#span" + labelIndex).css("left", $(currentElement).offset().left);
            $("#span" + labelIndex).css("top", $(currentElement).offset().top); // + $(currentElement).height() //- $(currentElement).prop('scrollHeight')
            //$("#span" + labelIndex).attr("data-obj", "schemaName="+"xx"+";selector="+"yy");
            $("#span" + labelIndex + " .delete").attr("data-index", labelIndex);
            $("#span" + labelIndex + " .edit").attr("data-index", labelIndex);

            selectedAssetType = $("#assetType").val();
            selectedAssetSubType = $("#assetSubType").val();

            $("#span" + labelIndex + " .delete").attr("data-fieldType", selectedAssetType + "---" + selectedAssetSubType);

            //hoverByClass(currentEleSelector, "class-highlighter "+labelIndex);
            $(".class-highlighter").removeClass("class-highlighter");

            //$("#span"+labelIndex).css("z-index",1000+labelIndex);
            // $("#span" + labelIndex).bind("contextmenu", function(e) {
            // return false;
            // });
            $("#span" + labelIndex + " .edit").bind("click", function(e) {
                $("#devMode").show();
                editIndex = $(e.target).attr("data-index");
                id = $(e.target).parent().attr("id");
                editClicked = true;
                changeTab(1)
                iframe.contentWindow.postMessage([
                    'Edit', editIndex, null
                ], '*');
            });
            $("#span" + labelIndex + " .delete").bind("click", function(e) {

                var confirmFromUser = confirm("Are you sure to delete the mapped item?");

                // Messenger().post({
                //   message: 'Definition save error..!',
                //   type: 'error'
                //   });

                if (confirmFromUser) {

                    var assetType = $(e.target).attr("data-fieldType").split("---");
                    $(e.target).parent().remove();
                    editIndex = $(e.target).attr("data-index");
                    $("#ssLabels_" + editIndex).remove();
                    var len_ = assetTypeObject.length;
                    for (var i = 0; i < len_; i++) {
                        if ((assetTypeObject[i][0] == assetType[0]) && (assetTypeObject[i][1] == assetType[1])) {
                            assetTypeObject.splice(i, 1);
                            break;
                        }
                    }

                    iframe.contentWindow.postMessage([
                        'Remove', $(e.target).attr("data-index"), null
                    ], '*');

                }
            });

            assetTypePush();

            if ($("#linksOrFieldsDropdown").val() == "links") {
                iframe.contentWindow.postMessage([
                    'addLink', linkObj
                ], '*');
            } else if ($("#linksOrFieldsDropdown").val() == "fields") {
                fieldObj.attribute = "";
                iframe.contentWindow.postMessage([
                    'addField', fieldObj
                ], '*');
                //console.log(JSON.stringify(fieldObj));
            } else if ($("#linksOrFieldsDropdown").val() == "images") {
                fieldObj.attribute = "src";
                iframe.contentWindow.postMessage([
                    'addField', fieldObj
                ], '*');
                //console.log(JSON.stringify(fieldObj));
            }

            $('#assetSubType').val('select');
            $('#linksOrFieldsDropdown').val('links');
            $(".splitWraper").hide();
            //$("#functionWraper").hide();
            $("#SplitError").hide();
            //$("#div_Scheme").hide();
            //$("#div_Scheme1").hide();
            $('#selectorVal').val('');
            $('#actionType').val('select');
            $('a').unbind("click.myDisable");
            $('#loginActionType').val('select');
            $('#loginActionElem').val('');
            //$(document).bind("contextmenu", rightClick);
            labelIndex++;
        }

        localStorage.setItem("pageObj", JSON.stringify(pageObj));
        multipleSelector = [];
    } else {
      Messenger().post("Please select attribute name before adding");
    }
});

//binding assetTypeId and attributeId
var assetTypeId = "";
$("#assetType").change(function() {

    var assetTypeId = $('#assetType option:selected').attr('data-assettypeid');
    var assetType = $('#assetType').val();
    fieldObj.assetTypeId = assetTypeId;
    fieldObj.assetType = assetType;
    linkObj.assetTypeId = assetTypeId;
    linkObj.assetType = assetType;


});

var attributeId = "";
$(".assetSubType").change(function() {

    var attributeId = $('.assetSubType option:selected').attr('data-attributeId');
    fieldObj.attributeId = attributeId;
    linkObj.attributeId = attributeId;
    //linkObj.name=$("#cntnr #assetSubType").val();

});


var loginFlowComplete = false;
$("#loginOk").click(function() {
    signinObject.postActions.push(localStorePostActions);
    if (signinObject.postActions != [] && signinObject.password.content != "" && signinObject.userName.content != "") {
        iframe.contentWindow.postMessage([
            'updaterootObject', signinObject
        ], '*');

        Messenger().post("Login details tracked successfully..! Please login to continue...");
    }
    $('#loginActionType').val('select');
    $('#loginActionElem').val('');
    loginFlowComplete = true;
});

// $("#cancel").click(function() {
//     //$("#cntnr").hide();
//     //$(currentElement).css("outline", "none");
//     $(document).unbind("click");
//     $(".ok").css('opacity', '1.0');
//     $('#assetType').val('select');
//     $('#assetSubType').val('select');
//     $('#linksOrFieldsDropdown').val('links');
//     $(".splitWraper").hide();
//     $("#functionWraper").hide();
//     $("#delimiterWrapper").hide();
//     $("#functionType").val('0');
//     $("#SplitError").hide();
//     //$("#div_Scheme").hide();
//     //$("#div_Scheme1").hide();
//     $("#fieldsError").hide();
//     $('#selectorVal').val('');
//     $('#actionType').val('select');
//     $('#loginActionType').val('select');
//     $('#loginActionElem').val('');
//     $(".class-highlighter").removeClass("class-highlighter");
//     $(document).bind("contextmenu", rightClick);
//     $('a').unbind("click.myDisable");
//
// });


$("#close,#iconClose").click(function() {
    $('#validateModal').modal('hide');
});


//$('#linksOrFieldsDropdown').change(function() {
$('#assetSubType').change(function() {
    // if ($(this).val() == "image") {
    //   if($(currentElement).tagName != "IMG")) { // elements in the selector input
    //     if (checkElementHasImage(currentElement)) {
    //         currentElement = $(currentElement).find("IMG:eq(0)")[0];
    //         Messenger().post("To select the link please rightclick on the link again!");
    //         //$('#selectorVal').val($('#selectorVal').val() + ' IMG');
    //     }
    //   } else {}
    // } else if ($(this).val() == "url") {
    //     if(checkElementHasA(currentElement)) {
    //       $(currentElement).parents().each(function(index, element) {
    //         if(element.tagName=="A") {
    //           currentElement = element;
    //         }
    //       });
    //
    //     }
    // } else {
    //
    // }
    //
    // updateSelectorVal(currentElement);

    //$('#selectorVal').val($('#selectorVal').val() + ' IMG');


});


$('.fnDropdown').bind('change', function() {
    selectedFn = $(".fnDropdown").find("option:selected").text();
    if (selectedFn == "Select a function") {
        $("#delimiterWrapper").hide();
        $(".splitWraper").hide();
        $("#subSrtingWraper").hide();
        $("#SplitError").hide();
    }
    //console.log("ahgdshdghgjdj dropdown_selector" + selectedFn);
    fnDropdown();
});




function fnDropdown() {

    selectedFn = $(".fnDropdown").find("option:selected").text();
    if (selectedFn == "Select a function") {
        fieldObj.function.name = "";
    }
    //code for split function
    if (selectedFn == "split") {

        $('<br/><div id="delimiterWrapper"><span class="formLabel">Delimiter:</span><input id="delimiter" name="input[]"  type="text"></input></div>').insertAfter(".fnDropdown");
        var string, delimiter;

        $('#delimiter').change(function(e) {
            delimiter = $("#delimiter").val();
            //console.log(delimiter);
            $("#SplitError").hide();
            //console.log("content is this selected" + content);
            stringContent = content.trim(); // remove multiple spaces in between

            fieldObj.function.parameters.param1 = stringContent;
            fieldObj.function.parameters.param2 = delimiter;

            if (delimiter.length !== 0 && delimiter !== "undefined" && delimiter !== null) {
                var postData = {
                    string: stringContent,
                    delimeter: delimiter
                };

                fieldObj.function.name = selectedFn;


                $.ajax(domainUrl + "/vcrawler/functions/split/", {
                    type: 'GET',
                    crossDomain: true,
                    ContentType: "application/json; charset=UTF-8",
                    data: postData,
                    success: function(response) {
                        response = eval(response);
                        //alert(response['output']);
                        var length = response['output'].length;


                        if (length > 1) fieldObj.function.multiOut = selectedFn;
                        if (response['output'] == "split function can't be applied") {
                            $(".ok").css('opacity', '0.6');
                            $(".ok").prop("disabled", true);
                            $('<div id="SplitError" style=color:red;>Split function can not be applied on this element.</div>').insertAfter("#delimiterWrapper");
                        } else {
                            $(".ok").css('opacity', '1.0');
                            for (var i = 0; i < length; i++) {
                                $('<div id="' + i + '" class="splitWraper" style="margin-top:3px;"><select class="test" id="splituserval' + i + '" name="input[]"  type="text" style="width:100px; margin-right:5px;"></select><input id="splitdata' + i + '" class="splitDisabled" style="width:100px" value="' + response['output'][i] + '"></input></div>').insertAfter("#functionBlock");
                                $(".splitDisabled").prop('disabled', true);

                                fieldObj.function.fields.push({
                                    "name": "",
                                    "index": i
                                });

                            }
                        }
                        $(".assetSubType option").clone(true).appendTo("select.test");

                        $("select.test").bind('change', function() {
                            fieldObj.function.fields[$(this).parent().attr("id")].name = $(this).val();
                            // console.log("ashdgajdkhsgjhgeqwyegqwyqwyegwquyeg"+$(this).val());
                        });

                        $(".assetType").bind('change', function() {
                            $('select.test option').remove();
                            $(".assetSubType option").clone(true).appendTo("select.test");
                        });
                    }
                });



            }
        });


    }

    //code for substring function
    // if (selectedFn == "substring") {
    //     $('<div>start_index: <input id="start_index" class="start_index" name="input[]"  type="text"></input></div>').insertAfter(".fnDropdown");
    //     $('<div>end_index: <input id="end_index" class="end_index" name="input[]"  type="text"></input></div>').insertAfter(".start_index");
    //     $('#end_index').bind('change', function(e) {
    //         var start_index = $("#start_index").val();
    //         var end_index = $("#end_index").val();
    //         stringContent = content.trim();
    //         var postData = {
    //             string: stringContent,
    //             start_index: start_index,
    //             end_index: end_index
    //         };
    //         if (start_index.length !== 0 && start_index !== "undefined" && start_index !== null && end_index.length !== 0 && end_index !== "undefined" && end_index !== null) {
    //             $.ajax(domainUrl + "/vcrawler/functions/get_substring/", {
    //                 type: 'GET',
    //                 crossDomain: true,
    //                 ContentType: "application/json; charset=UTF-8",
    //                 data: postData,
    //                 success: function(response) {
    //                     response = eval(response);
    //                     alert(response['output']);
    //                     $('<div style="margin-top:3px;"><select class="test" id="subStringuserval" name="input[]"  type="text" style="width:100px; margin-right:5px;"></select><input id="substringdata" class="splitDisabled" style="width:100px" value="' + response['output'] + '"></input></div>').insertBefore(".ok");
    //                     $(".assetSubType option").clone(true).appendTo("select.test");
    //                     //alert(response);
    //                     $(".assetType").bind('change', function() {
    //                         $('select.test option').remove();
    //                         $(".assetSubType option").clone(true).appendTo("select.test");
    //                     });
    //                 }
    //             });
    //         }
    //
    //     });
    //
    // }


}

$(document).ready(function() {
    populateAsset();
    setTimeout(function() {
      $('body').append($('.messenger'));
    }, 1000);
    // post a roviMsg with window url
});



$(window).ready(function() {
    setTimeout(function() {
        iframe.contentWindow.postMessage([
            'currentPageUrl', window.location.href
        ], '*');
    }, 500);
});



function populateAsset() {

    $.ajax({
        type: "GET",
        url: domainUrl + "/tivo_spider/get_field/", //url:"http://172.26.119.65:8000/tivo_spider/get_field/",
        dataType: "json",
        success: function(data) {
            result = data;
            for (var i = 0; i < data.assets.length; i++) {
                //console.log(data.assets[i].name);
                //   for (var j=0; data['assets'][i].fields.length; j++) {
                //console.log("Item name: "+data.assets);
                //console.log("Source: "+data.assets[i].fields);


                // alert(data.value+":"+data.text);
                var div_data = "<option value=" + data.assets[i].name + " data-assettypeid=" + data.assets[i].assetTypeID + ">" + data.assets[i].name + "</option>";
                // alert(div_data);
                $(div_data).appendTo('.assetType');

            }
            $('#assetType').bind('change', function(e) {
                selectedAssetType = $('.assetType').val();

                //$('.assetSubType option').remove();
                $('.assetSubType option').not(':first').remove();
                var test = document.getElementById("assetType").selectedIndex;
                //console.log(selectedAssetType);
                for (var i = 0; i < data.assets.length; i++) {
                    if (data.assets[i].name == selectedAssetType) {
                        for (var j = 0; j < data.assets[i].fields.length; j++) {
                            //console.log(data.assets[i].fields);
                            div_data1 = "<option value='" + data.assets[i].fields[j][0] + "' data-attributeId='" + data.assets[i].fields[j][1] + "'>" + data.assets[i].fields[j][0] + "</option>";
                            // alert(div_data);
                            $(div_data1).appendTo('.assetSubType');
                        }
                        //$('#assetSubType').css('overflow','scroll');
                    }

                }

            });


        }
    });

}

//$("#div_Scheme").hide();
//$("#div_Scheme1").hide();
//hide and show for function wrapper on dropdown select.
$("#linksOrFieldsDropdown").bind('change', function() {
    if ($("#linksOrFieldsDropdown").val() == "fields") {
        //$("#functionWraper").show();
        //$("#div_Scheme").show();
        //$("#div_Scheme1").show();

    } else {
        //$("#functionWraper").hide();
        $(".splitWraper").hide();
        //$("#div_Scheme").hide();
        //$("#div_Scheme1").hide();
    }


});


var windows = document.querySelectorAll('.window');
[].forEach.call(windows, function(win) {
    var title = win.querySelector('.titlebar');
    title.addEventListener('mousedown', function(evt) {

        // Record where the window started
        var real = window.getComputedStyle(win),
            winX = parseFloat(real.left),
            winY = parseFloat(real.top);

        // Record where the mouse started
        var mX = evt.clientX,
            mY = evt.clientY;

        // When moving anywhere on the page, drag the window
        // …until the mouse button comes up
        document.body.addEventListener('mousemove', drag, false);
        document.body.addEventListener('mouseup', function() {
            document.body.removeEventListener('mousemove', drag, false);
        }, false);

        // Every time the mouse moves, we do the following
        function drag(evt) {
            // Add difference between where the mouse is now
            // versus where it was last to the original positions
            win.style.left = winX + evt.clientX - mX + 'px';
            win.style.top = winY + evt.clientY - mY + 'px';
        };
    }, false);
});

// modal window //
var modal = document.getElementById('userModalPopup');
var validateModal = document.getElementById('userModalPopup1');

var btnClose = document.getElementById("btnClose");
var btnCloseTop = document.getElementById("btnCloseTop");

btnClose.onclick = function() {
    modal.style.display = "none";
}
btnCloseTop.onclick = function() {
    modal.style.display = "none";
}


selectedAssetType = "";
selectedAssetSubType = "";

function assetTypePush() {
    selectedAssetType = $("#assetType").val();
    selectedAssetSubType = $("#assetSubType").val();

    if (selectedAssetType !== "select" && selectedAssetType !== "") {
        assetTypeObject.push([selectedAssetType, selectedAssetSubType]);
    }
}

$("#div_Scheme").bind('change', function() {
    selectedAssetType = $("#assetType").val();
    if ($.inArray(selectedAssetType, assetTypeObject[selectedAssetType]) < 0) {
        $("#assetType").removeClass(".error");
        //$("#fieldsError").hide();
        $(".ok").prop("disabled", false);
        $(".ok").css('opacity', '1.0');
    } else {
        $("#assetType").addClass(".error");
        //$("#fieldsError").show();
        $(".ok").prop("disabled", true);
        $(".ok").css('opacity', '0.6');
        Messenger().post("Selected combination is already defined in schema.");
    }
});


$("#div_Scheme1").bind('change', function() {
    selectedAssetType = $("#assetType").val();
    selectedAssetSubType = $("#assetSubType").val();
    var fieldAlreadyMaped = false;
    var len = assetTypeObject.length;
    for (var i = 0; i < len; i++) {
        if ((assetTypeObject[i][0] == selectedAssetType) && (assetTypeObject[i][1] == selectedAssetSubType)) {
            fieldAlreadyMaped = true;
            break;
        }
    }
    if (fieldAlreadyMaped == false) {
        $("#assetSubType").removeClass(".error");
        //$("#fieldsError").hide();
        $(".ok").prop("disabled", false);
        $(".ok").css('opacity', '1.0');
    } else {
        $("#assetSubType").addClass(".error");
      //  $("#fieldsError").show();
        $(".ok").prop("disabled", true);
        $(".ok").css('opacity', '0.6');
        Messenger().post("Selected combination is already defined in schema.");
    }
});
//assetType check logic End


//Action logic start
$("#actionType").bind('change', function() {
    var selectedFAction = $("#actionType").find("option:selected").val();
    if (selectedFAction == "click") {
        //$('a').bind("click.myDisable", function() { return false; });
        $("*").click(function(e) {
            //console.log(getPathTo(e.target));
            //if($(getPathTo(e.target)).parents() !=="div#cntnr")
            if (!$(e.target).parents().is('#cntnr') && !$(e.target).is('.stepNumber')) {
                var elms = getPathTo(e.target);
                var elms1 = elms.startsWith(".");
                $('#actionElem').val("");
                //console.log(elms);
                if (elms.startsWith(".")) {
                    var elms1 = "[class^='" + elms.substring(1) + "']";
                    $('#actionElem').val(elms1);
                } else if (elms.startsWith("#")) {
                    var elms1 = "[id*='" + elms.substring(1) + "']";
                    $('#actionElem').val(elms1);
                }
            }
            $('#actionElem').show();
            $('#elementwrapper').show();
        });
    }
    /*else {
                 $('a').unbind("click.myDisable");
     }*/
    if (selectedFAction == "scroll" || selectedFAction == "select") {
        $('#actionElem').val('');
        //$('#elementwrapper').val("");
        // $('#actionElem').hide();
        $('#elementwrapper').hide();
    }
});

//change for login start
var traceLoginUrl = "",
    loginElms = "",
    localStorePostActions = "",
    firstUrl = "";
$("#loginTrackBtn").bind('click', function() {
    loginFlowComplete = false;
    var selectedFAction = "click"; //$("#loginActionType").find("option:selected").val();
    if (selectedFAction == "click") {
        $("*").click(function(e) {
            if (!$(e.target).parents().is('#cntnr') && !$(e.target).is('.tabs') && !$(e.target).is('#loginTrackBtn')) {
                loginElms = getPathTo(e.target);

                $(loginElms).bind('change', function(e) {
                    if ($(loginElms).attr('type') == "password") {
                        var capturPassword = $(loginElms).val();
                        signinObject.password.content = capturPassword;
                        captureLoginUnP(loginElms, "#loginActionElemP");
                    }
                    if ($(loginElms).attr('type') == "text") {
                        var capturText = $(loginElms).val();
                        signinObject.userName.content = capturText;
                        captureLoginUnP(loginElms, "#loginActionElemU");
                    }
                });
            }
            $('#elementwrapper').show();
        });
    }

    $(document).bind("contextmenu", function(e) {
        if (!$(e.target).parents().is('#cntnr') && !$(e.target).is('.tabs') && !$(e.target).is('#loginTrackBtn')) {
            loginElms = getPathTo(e.target);
        }
        $("#loginActionBtn").val(loginElms);
        //window.location.href =  pathname.href + '?action=roviWebScraperActive';
        localStorePostActions = {
            "url": window.location.href,
            "action": "click",
            "value": loginElms,
            "type": "css selector"
        }
    });
});

function captureLoginUnP(content, input) {
        if (content.startsWith(".")) {
            var elms1 = "[class^='" + content.substring(1) + "']";
        } else if (content.startsWith("#")) {
            var elms1 = "[id*='" + content.substring(1) + "']";
        }
        $(input).val(elms1);
        if (input == "#loginActionElemU") {
            signinObject.userName.value = elms1;
        } else {
            signinObject.password.value = elms1;
        }
    }
    //change for login end
//Chrome extension tab//
var prevStepId = 1;
function changeTab(n) {
    $("#step-" + prevStepId + "-c").css("display", "none");
    $("#th" + prevStepId).removeClass("selected");
    $("#step-" + n + "-c").css("display", "block");
    $("#th" + n).addClass("selected");
    prevStepId = n;
}
$('.subsessionWidget .header').click(function() {
    $(this).next().toggle();
});
var currentAssetIndex = -1;

$("#addAsset").click(function() {
    $("#devMode").hide();
    $("#AssetIdSelectorVal").val('');
    $("#AssetTitleSelectorVal").val('');
    $("#subsessionbtn").empty();
    $("#subSessionContent").empty();
    $("#subSessionDone").hide();

    //$(".assetTypeLabels").empty();
    currentAssetIndex++;
    pageObj[0].assets.push({
        "assetTitle": $("#assetType").val(),
        "activeAsset": true,
        "currentSubSession": "listing",
        "roviCurrentQ": 1,
        "subSessions": {}
    });
    var assetsMapped = $("#assetTypeContainer").text();
    assetToAdd = $("#assetType").val();
    if (assetsMapped.indexOf(assetToAdd) < 0 && $("#assetType").val() != "select") {
        $("#assetTypeContainer").show();
        $("#div_Scheme").hide();
        $(".assetSSContainer").show();


        $("#assetTypeContainer .assetTypeLabels.active").removeClass("active");
        $("#subSessionContainer").hide();
        currentSelectedAsset = $(this).text();
        // change the current asset code
        var btn = $('<button/>', {
            text: $("#assetType").val(),
            class: 'assetTypeLabels active',
            click: function() {
                loadAssetDetails($(this).text());
                changeAssetTab();
            }
        });
        $("#assetTypeContainer").append(btn);
        roviCurrentQ++;
        throwMessage();

        $("#subSessionContainer .subSessionLabels.active").removeClass("active");
        var btn = $('<button/>', {
            text: "Attributes",
            class: 'subSessionLabels active',
            click: function() {

            }
        });
        $("#subsessionbtn").append(btn);
    } else {
        Messenger().post("Asset is already added or you have not selected any asset.");
    }
    //$(document).bind("contextmenu", rightClick);
});

function changeAssetTab() {
    $('.assetTypeLabels').add('active')
        .toggleClass("assetTypeLabels").toggleClass("assetTypeLabels active");
}

function loadAssetDetails(str) {
    $("#assetDetails").find("legend").text(str);
}
